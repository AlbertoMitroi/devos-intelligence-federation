# Repository overview

- Commit: `00891c7e88ca50bdcf9976d6b82745157e380518`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Pricing.sln` (sln)

## Projects

| Project | Load mode | Target framework | Types | Card |
|---|---|---|---|---|
| `src/Pricing.Api/Pricing.Api.csproj` | semantic | net8.0 | 13 | [card](projects/Pricing.Api-5757cae5.md) |
| `src/Pricing.Client/Pricing.Client.csproj` | semantic | net8.0 | 6 | [card](projects/Pricing.Client-bde5904e.md) |
| `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj` | semantic | net8.0 | 4 | [card](projects/Pricing.Api.Tests-7db41b31.md) |

## Project references

```mermaid
flowchart LR
  p5757cae567["Pricing.Api"]
  pbde5904ed7["Pricing.Client"]
  p7db41b3167["Pricing.Api.Tests"]
  p7db41b3167 --> p5757cae567
  p7db41b3167 --> pbde5904ed7
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 13 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 5 of 7 links are unresolved; each has its reason in graph/links.ndjson.

# Repository overview

- Commit: `0ee03cc9eb17ee35c918fa8c8bce7b9110d9238f`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Pricing.sln` (sln)

## Services

| Project | Kind | Endpoints | Outgoing calls | Published | Subscribed | Card |
|---|---|---|---|---|---|---|
| `src/Pricing.Api/Pricing.Api.csproj` | service | 5 | 0 | 0 | 0 | [card](projects/Pricing.Api-5757cae5.md) |
| `src/Pricing.Client/Pricing.Client.csproj` | library | 0 | 3 | 0 | 0 | [card](projects/Pricing.Client-bde5904e.md) |
| `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj` | test | 0 | 2 | 0 | 0 | [card](projects/Pricing.Api.Tests-7db41b31.md) |

## Service map

- `Pricing.Api.Tests` → `Pricing.Client` via di: 1 link(s), strongest exact; for example tests/Pricing.Api.Tests/PricingClientTests.cs:25

5 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Contracts

None found.

## Projects

| Project | Kind | Load mode | Target framework | Types | Card |
|---|---|---|---|---|---|
| `src/Pricing.Api/Pricing.Api.csproj` | service | semantic | net8.0 | 13 | [card](projects/Pricing.Api-5757cae5.md) |
| `src/Pricing.Client/Pricing.Client.csproj` | library | semantic | net8.0 | 6 | [card](projects/Pricing.Client-bde5904e.md) |
| `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj` | test | semantic | net8.0 | 4 | [card](projects/Pricing.Api.Tests-7db41b31.md) |

## Project references

```mermaid
flowchart LR
  n5757cae567["Pricing.Api"]
  nbde5904ed7["Pricing.Client"]
  n7db41b3167["Pricing.Api.Tests"]
  n7db41b3167 --> n5757cae567
  n7db41b3167 --> nbde5904ed7
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 13 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 5 of 7 links are unresolved; each has its reason in graph/links.ndjson.
- 5 unresolved links; each project card lists its own with the reason.

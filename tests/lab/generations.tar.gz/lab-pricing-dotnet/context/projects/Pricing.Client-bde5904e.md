# Pricing.Client

- Project: `src/Pricing.Client/Pricing.Client.csproj`
- Kind: library
- Assembly: Pricing.Client
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Pricing.sln`

## Endpoints (0)

None found.

## Outgoing calls (3)

- POST `/api/quotes` (exact), src/Pricing.Client/PricingClient.cs:10; → unresolved: No typed-client registration with a base address was found for the calling client.
- GET `/api/quotes/{}` (candidate), src/Pricing.Client/PricingClient.cs:17; → unresolved: No typed-client registration with a base address was found for the calling client.
- POST `/api/quotes/{}/recalculate` (candidate), src/Pricing.Client/PricingClient.cs:29; → unresolved: No typed-client registration with a base address was found for the calling client.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 2 consumed services)

Lifetimes: 1 transient.

- `T:Pricing.Client.IPricingClient` → `T:Pricing.Client.PricingClient` (transient), src/Pricing.Client/ServiceCollectionExtensions.cs:13

## Configuration keys (0, values never stored)

None found.

## Project references

None.

## Direct packages

- Microsoft.Extensions.Http 8.0.1
- Microsoft.Extensions.Options.ConfigurationExtensions 8.0.0

## Types (6)

- interface `Pricing.Client.IPricingClient` (public), src/Pricing.Client/IPricingClient.cs:3
- record `Pricing.Client.PricedQuote` (public), src/Pricing.Client/Contracts.cs:5
- class `Pricing.Client.PricingClientOptions` (public), src/Pricing.Client/PricingClientOptions.cs:3
- record `Pricing.Client.QuoteRequest` (public), src/Pricing.Client/Contracts.cs:3
- class `Pricing.Client.ServiceCollectionExtensions` (public), src/Pricing.Client/ServiceCollectionExtensions.cs:7
- class `Pricing.Client.PricingClient` (internal), src/Pricing.Client/PricingClient.cs:6

## Used by other projects

- `System.Threading.Tasks.Task<Pricing.Client.PricedQuote> Pricing.Client.IPricingClient.CalculateQuoteAsync(Pricing.Client.QuoteRequest request, [System.Threading.CancellationToken cancellationToken])`: 6 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `System.Threading.Tasks.Task<Pricing.Client.PricedQuote?> Pricing.Client.IPricingClient.GetQuoteAsync(System.Guid quoteId, [System.Threading.CancellationToken cancellationToken])`: 4 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `System.Guid Pricing.Client.PricedQuote.QuoteId`: 4 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Client.QuoteRequest.QuoteRequest(string ProductCode, string AssetType, decimal AssetValue, int TermMonths)`: 3 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `decimal Pricing.Client.PricedQuote.MonthlyPayment`: 3 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Client.QuoteRequest`: 3 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `System.Threading.Tasks.Task<Pricing.Client.PricedQuote> Pricing.Client.IPricingClient.RecalculateQuoteAsync(System.Guid quoteId, int termMonths, [System.Threading.CancellationToken cancellationToken])`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Microsoft.Extensions.DependencyInjection.IHttpClientBuilder Pricing.Client.ServiceCollectionExtensions.AddPricingClient(Microsoft.Extensions.DependencyInjection.IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `decimal Pricing.Client.PricedQuote.ResidualPercent`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Client.IPricingClient`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `decimal Pricing.Client.PricedQuote.RatePercent`: 1 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `int Pricing.Client.PricedQuote.TermMonths`: 1 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 13 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 5 of 7 links are unresolved; each has its reason in graph/links.ndjson.
- unresolved http link from http.call at src/Pricing.Client/PricingClient.cs:10: No typed-client registration with a base address was found for the calling client.
- unresolved http link from http.call at src/Pricing.Client/PricingClient.cs:17: No typed-client registration with a base address was found for the calling client.
- unresolved http link from http.call at src/Pricing.Client/PricingClient.cs:29: No typed-client registration with a base address was found for the calling client.

# Pricing.Api

- Project: `src/Pricing.Api/Pricing.Api.csproj`
- Kind: service
- Assembly: Pricing.Api
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Pricing.sln`

## Entry points

- top-level statements, src/Pricing.Api/Program.cs:10

## Endpoints (5)

- POST `/api/quotes` → `M:Pricing.Api.Controllers.QuotesController.Calculate(Pricing.Api.Controllers.CalculateQuoteRequest,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:27
- GET `/api/quotes/{}` → `M:Pricing.Api.Controllers.QuotesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:41
- POST `/api/quotes/{}/recalculate` → `M:Pricing.Api.Controllers.QuotesController.Recalculate(System.Guid,Pricing.Api.Controllers.RecalculateQuoteRequest,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:48
- GET `/api/rate-cards/{}` → `unknown`, src/Pricing.Api/Endpoints/RateCardEndpoints.cs:16
- GET `/api/residual-values` → `unknown`, src/Pricing.Api/Endpoints/RateCardEndpoints.cs:21

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 4 consumed services)

Lifetimes: 1 singleton.

- `T:System.TimeProvider` → `T:System.TimeProvider` (singleton), src/Pricing.Api/Program.cs:10

## Data (6)

- table `rate_cards` ← `T:Pricing.Api.Data.RateCardEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:17
- table `residual_values` ← `T:Pricing.Api.Data.ResidualValueEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:26
- table `quotes` ← `T:Pricing.Api.Data.QuoteEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:37
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.QuoteEntity`, src/Pricing.Api/Data/PricingDbContext.cs:11
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.RateCardEntity`, src/Pricing.Api/Data/PricingDbContext.cs:7
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.ResidualValueEntity`, src/Pricing.Api/Data/PricingDbContext.cs:9

## Configuration keys (5, values never stored)

- `AllowedHosts`, src/Pricing.Api/appsettings.json:8
- `ConnectionStrings:PricingDb` (secret), src/Pricing.Api/appsettings.Docker.json:3 and 2 more
- `Database:EnsureCreated`, src/Pricing.Api/appsettings.Docker.json:6 and 2 more
- `Logging:LogLevel:Default`, src/Pricing.Api/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Pricing.Api/appsettings.json:5

## Project references

None.

## Direct packages

- Microsoft.EntityFrameworkCore 8.0.11
- Npgsql.EntityFrameworkCore.PostgreSQL 8.0.11
- Swashbuckle.AspNetCore 6.9.0

## Types (13)

- record `Pricing.Api.Controllers.CalculateQuoteRequest` (public), src/Pricing.Api/Controllers/QuotesController.cs:8
- record `Pricing.Api.Controllers.QuoteResponse` (public), src/Pricing.Api/Controllers/QuotesController.cs:12
- class `Pricing.Api.Controllers.QuotesController` (public), src/Pricing.Api/Controllers/QuotesController.cs:25
- record `Pricing.Api.Controllers.RecalculateQuoteRequest` (public), src/Pricing.Api/Controllers/QuotesController.cs:10
- class `Pricing.Api.Data.PricingDbContext` (public), src/Pricing.Api/Data/PricingDbContext.cs:5
- class `Pricing.Api.Data.QuoteEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:65
- class `Pricing.Api.Data.RateCardEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:45
- class `Pricing.Api.Data.ResidualValueEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:56
- class `Pricing.Api.Endpoints.RateCardEndpoints` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:10
- record `Pricing.Api.Endpoints.RateCardResponse` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:6
- record `Pricing.Api.Endpoints.ResidualValueResponse` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:8
- class `Pricing.Api.Pricing.LeaseCalculator` (public), src/Pricing.Api/Pricing/LeaseCalculator.cs:3
- class `Program` (public), src/Pricing.Api/Program.cs:35

## Used by other projects

- `decimal Pricing.Api.Pricing.LeaseCalculator.MonthlyPayment(decimal assetValue, decimal annualRatePercent, int termMonths, decimal residualPercent)`: 4 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Api.Data.PricingDbContext`: 3 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Api.Pricing.LeaseCalculator`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Program`: 1 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 13 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 5 of 7 links are unresolved; each has its reason in graph/links.ndjson.
None found.

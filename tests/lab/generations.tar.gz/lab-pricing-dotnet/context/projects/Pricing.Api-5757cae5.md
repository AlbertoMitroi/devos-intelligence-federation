# Pricing.Api

- Project: `src/Pricing.Api/Pricing.Api.csproj`
- Assembly: Pricing.Api
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Pricing.sln`

## Project references

None.

## Direct packages

- Microsoft.EntityFrameworkCore 8.0.11
- Npgsql.EntityFrameworkCore.PostgreSQL 8.0.11
- Swashbuckle.AspNetCore 6.9.0

## Types (13)

- record `Pricing.Api.Controllers.CalculateQuoteRequest` (public), src/Pricing.Api/Controllers/QuotesController.cs:8
- record `Pricing.Api.Controllers.QuoteResponse` (public), src/Pricing.Api/Controllers/QuotesController.cs:12
- class `Pricing.Api.Controllers.QuotesController` (public), src/Pricing.Api/Controllers/QuotesController.cs:25
- record `Pricing.Api.Controllers.RecalculateQuoteRequest` (public), src/Pricing.Api/Controllers/QuotesController.cs:10
- class `Pricing.Api.Data.PricingDbContext` (public), src/Pricing.Api/Data/PricingDbContext.cs:5
- class `Pricing.Api.Data.QuoteEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:65
- class `Pricing.Api.Data.RateCardEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:45
- class `Pricing.Api.Data.ResidualValueEntity` (public), src/Pricing.Api/Data/PricingDbContext.cs:56
- class `Pricing.Api.Endpoints.RateCardEndpoints` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:10
- record `Pricing.Api.Endpoints.RateCardResponse` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:6
- record `Pricing.Api.Endpoints.ResidualValueResponse` (public), src/Pricing.Api/Endpoints/RateCardEndpoints.cs:8
- class `Pricing.Api.Pricing.LeaseCalculator` (public), src/Pricing.Api/Pricing/LeaseCalculator.cs:3
- class `Program` (public), src/Pricing.Api/Program.cs:35

## Entry points

- top-level statements

## Used by other projects

- `decimal Pricing.Api.Pricing.LeaseCalculator.MonthlyPayment(decimal assetValue, decimal annualRatePercent, int termMonths, decimal residualPercent)`: 4 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Api.Data.PricingDbContext`: 3 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Pricing.Api.Pricing.LeaseCalculator`: 2 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- `Program`: 1 usages from `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 13 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 5 of 7 links are unresolved; each has its reason in graph/links.ndjson.

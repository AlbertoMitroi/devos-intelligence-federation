# Repository wiki

- Commit: `0ee03cc9eb17ee35c918fa8c8bce7b9110d9238f`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Service map

```mermaid
flowchart LR
  nbde5904ed7["Pricing.Client"]
  n7db41b3167["Pricing.Api.Tests"]
  n7db41b3167 -->|"di ×1"| nbde5904ed7
```

- `Pricing.Api.Tests` → `Pricing.Client` via di: 1 link(s), strongest exact; for example tests/Pricing.Api.Tests/PricingClientTests.cs:25

5 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Services

- [Pricing.Api](services/Pricing.Api-5757cae5.md) (service), `src/Pricing.Api/Pricing.Api.csproj`
- [Pricing.Client](services/Pricing.Client-bde5904e.md) (library), `src/Pricing.Client/Pricing.Client.csproj`
- [Pricing.Api.Tests](services/Pricing.Api.Tests-7db41b31.md) (test), `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`

## Contracts

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> dump`

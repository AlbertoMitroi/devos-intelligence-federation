# Pricing.Api.Tests

- Commit: `0ee03cc9eb17ee35c918fa8c8bce7b9110d9238f`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `tests/Pricing.Api.Tests/Pricing.Api.Tests.csproj`
- Kind: test
- Context card: [context/projects/Pricing.Api.Tests-7db41b31.md](../../context/projects/Pricing.Api.Tests-7db41b31.md)

## Neighbours

```mermaid
flowchart LR
  nbde5904ed7["Pricing.Client"]
  n7db41b3167[["Pricing.Api.Tests"]]
  n7db41b3167 -->|"di ×1"| nbde5904ed7
```

## Endpoints (0)

None found.

## Outgoing calls (2)

- GET `/api/rate-cards/eq-flex` (exact), tests/Pricing.Api.Tests/PricingClientTests.cs:71; → unresolved: No typed-client registration with a base address was found for the calling client.
- GET `/api/residual-values` (exact), tests/Pricing.Api.Tests/PricingClientTests.cs:75; → unresolved: No typed-client registration with a base address was found for the calling client.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 3 consumed services)

None found.

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Pricing.Api.Tests --kind entity`

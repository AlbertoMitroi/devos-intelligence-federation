# Pricing.Client

- Commit: `0ee03cc9eb17ee35c918fa8c8bce7b9110d9238f`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Pricing.Client/Pricing.Client.csproj`
- Kind: library
- Context card: [context/projects/Pricing.Client-bde5904e.md](../../context/projects/Pricing.Client-bde5904e.md)

## Neighbours

```mermaid
flowchart LR
  nbde5904ed7[["Pricing.Client"]]
  n7db41b3167["Pricing.Api.Tests"]
  n7db41b3167 -->|"di ×1"| nbde5904ed7
```

## Endpoints (0)

None found.

## Outgoing calls (3)

- POST `/api/quotes` (exact), src/Pricing.Client/PricingClient.cs:10; → unresolved: No typed-client registration with a base address was found for the calling client.
- GET `/api/quotes/{}` (candidate), src/Pricing.Client/PricingClient.cs:17; → unresolved: No typed-client registration with a base address was found for the calling client.
- POST `/api/quotes/{}/recalculate` (candidate), src/Pricing.Client/PricingClient.cs:29; → unresolved: No typed-client registration with a base address was found for the calling client.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 2 consumed services)

Lifetimes: 1 transient.

- `T:Pricing.Client.IPricingClient` → `T:Pricing.Client.PricingClient` (transient), src/Pricing.Client/ServiceCollectionExtensions.cs:13

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Pricing.Client --kind entity`

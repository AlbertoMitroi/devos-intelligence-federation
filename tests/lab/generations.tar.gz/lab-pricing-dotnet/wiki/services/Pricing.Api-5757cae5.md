# Pricing.Api

- Commit: `0ee03cc9eb17ee35c918fa8c8bce7b9110d9238f`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Pricing.Api/Pricing.Api.csproj`
- Kind: service
- Context card: [context/projects/Pricing.Api-5757cae5.md](../../context/projects/Pricing.Api-5757cae5.md)

## Neighbours

No links to or from other projects.

## Endpoints (5)

- POST `/api/quotes` → `M:Pricing.Api.Controllers.QuotesController.Calculate(Pricing.Api.Controllers.CalculateQuoteRequest,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:27
- GET `/api/quotes/{}` → `M:Pricing.Api.Controllers.QuotesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:41
- POST `/api/quotes/{}/recalculate` → `M:Pricing.Api.Controllers.QuotesController.Recalculate(System.Guid,Pricing.Api.Controllers.RecalculateQuoteRequest,System.Threading.CancellationToken)`, src/Pricing.Api/Controllers/QuotesController.cs:48
- GET `/api/rate-cards/{}` → `unknown`, src/Pricing.Api/Endpoints/RateCardEndpoints.cs:16
- GET `/api/residual-values` → `unknown`, src/Pricing.Api/Endpoints/RateCardEndpoints.cs:21

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 4 consumed services)

Lifetimes: 1 singleton.

- `T:System.TimeProvider` → `T:System.TimeProvider` (singleton), src/Pricing.Api/Program.cs:10

## Data (6)

- table `rate_cards` ← `T:Pricing.Api.Data.RateCardEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:17
- table `residual_values` ← `T:Pricing.Api.Data.ResidualValueEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:26
- table `quotes` ← `T:Pricing.Api.Data.QuoteEntity` (efcore), src/Pricing.Api/Data/PricingDbContext.cs:37
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.QuoteEntity`, src/Pricing.Api/Data/PricingDbContext.cs:11
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.RateCardEntity`, src/Pricing.Api/Data/PricingDbContext.cs:7
- `T:Pricing.Api.Data.PricingDbContext` maps `T:Pricing.Api.Data.ResidualValueEntity`, src/Pricing.Api/Data/PricingDbContext.cs:9

## Configuration keys (5, values never stored)

- `AllowedHosts`, src/Pricing.Api/appsettings.json:8
- `ConnectionStrings:PricingDb` (secret), src/Pricing.Api/appsettings.Docker.json:3 and 2 more
- `Database:EnsureCreated`, src/Pricing.Api/appsettings.Docker.json:6 and 2 more
- `Logging:LogLevel:Default`, src/Pricing.Api/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Pricing.Api/appsettings.json:5

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Pricing.Api --kind entity`

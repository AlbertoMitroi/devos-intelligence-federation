# Intake.Worker

- Project: `src/Intake.Worker/Intake.Worker.csproj`
- Assembly: Intake.Worker
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Intake.sln`

## Project references

- `src/Intake.Contracts/Intake.Contracts.csproj`

## Direct packages

- Confluent.SchemaRegistry.Serdes.Avro 2.16.0
- MassTransit 8.5.12
- MassTransit.Kafka 8.5.12

## Types (11)

- class `Intake.Worker.Endpoints.ApplicationEndpoints` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:10
- class `Intake.Worker.Endpoints.Enrichment` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:45
- record `Intake.Worker.Endpoints.SubmitApplicationRequest` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:6
- record `Intake.Worker.Endpoints.SubmitApplicationResponse` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:8
- interface `Intake.Worker.Publishing.IApplicationPublisher` (public), src/Intake.Worker/Publishing/IApplicationPublisher.cs:5
- class `Intake.Worker.Publishing.IntakeKafkaOptions` (public), src/Intake.Worker/Publishing/IntakeKafkaOptions.cs:3
- class `Intake.Worker.Publishing.IntakeTopics` (public), src/Intake.Worker/Publishing/IntakeKafkaOptions.cs:16
- class `Intake.Worker.Publishing.KafkaApplicationPublisher` (public), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:7
- class `Intake.Worker.Publishing.KafkaExtensions` (public), src/Intake.Worker/Publishing/KafkaExtensions.cs:8
- class `Intake.Worker.Publishing.LoggingApplicationPublisher` (public), src/Intake.Worker/Publishing/LoggingApplicationPublisher.cs:6
- class `Program` (public), src/Intake.Worker/Program.cs:17

## Entry points

- top-level statements

## Used by other projects

- `Intake.Worker.Publishing.IApplicationPublisher`: 3 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Lab.Intake.Contracts.LeaseApplicationEnriched Intake.Worker.Endpoints.Enrichment.For(string applicationId, string companyNumber)`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationRequest.SubmitApplicationRequest(string ApplicantName, string CompanyNumber, string AssetType, decimal AssetValue, int TermMonths)`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationRequest`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Intake.Worker.Endpoints.SubmitApplicationResponse.ApplicationId`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.Enrichment`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationResponse`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Program`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 6 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 4 of 5 links are unresolved; each has its reason in graph/links.ndjson.

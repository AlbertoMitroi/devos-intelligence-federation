# Intake.Worker

- Project: `src/Intake.Worker/Intake.Worker.csproj`
- Kind: service
- Assembly: Intake.Worker
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Intake.sln`

## Entry points

- top-level statements, src/Intake.Worker/Program.cs:10

## Endpoints (1)

- POST `/intake/applications` → `unknown`, src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:14

## Outgoing calls (0)

None found.

## Messages (2 published, 0 subscribed)

- publishes `dotnet:src/Intake.Contracts/Intake.Contracts.csproj:T:Lab.Intake.Contracts.LeaseApplicationSubmitted` (kafka, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Intake.Contracts/Intake.Contracts.csproj:T:Lab.Intake.Contracts.LeaseApplicationEnriched` (kafka, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:15; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Dependency injection (4 registrations, 3 consumed services)

Lifetimes: 1 scoped, 3 singleton.

- `T:System.TimeProvider` → `T:System.TimeProvider` (singleton), src/Intake.Worker/Program.cs:6
- `T:Intake.Worker.Publishing.IApplicationPublisher` → `T:Intake.Worker.Publishing.LoggingApplicationPublisher` (singleton, conditional), src/Intake.Worker/Publishing/KafkaExtensions.cs:16
- `T:Confluent.SchemaRegistry.ISchemaRegistryClient` → `T:Confluent.SchemaRegistry.CachedSchemaRegistryClient` (singleton), src/Intake.Worker/Publishing/KafkaExtensions.cs:20
- `T:Intake.Worker.Publishing.IApplicationPublisher` → `T:Intake.Worker.Publishing.KafkaApplicationPublisher` (scoped), src/Intake.Worker/Publishing/KafkaExtensions.cs:38

## Configuration keys (8, values never stored)

- `AllowedHosts`, src/Intake.Worker/appsettings.json:8
- `Kafka:BootstrapServers`, src/Intake.Worker/appsettings.Docker.json:3 and 1 more
- `Kafka:Enabled`, src/Intake.Worker/appsettings.Testing.json:3 and 1 more
- `Kafka:SchemaRegistryUrl`, src/Intake.Worker/appsettings.Docker.json:4 and 1 more
- `Kafka:Topics:Applications`, src/Intake.Worker/appsettings.json:14
- `Kafka:Topics:Enrichment`, src/Intake.Worker/appsettings.json:15
- `Logging:LogLevel:Default`, src/Intake.Worker/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Intake.Worker/appsettings.json:5

## Project references

- `src/Intake.Contracts/Intake.Contracts.csproj`

## Direct packages

- Confluent.SchemaRegistry.Serdes.Avro 2.16.0
- MassTransit 8.5.12
- MassTransit.Kafka 8.5.12

## Types (11)

- class `Intake.Worker.Endpoints.ApplicationEndpoints` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:10
- class `Intake.Worker.Endpoints.Enrichment` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:45
- record `Intake.Worker.Endpoints.SubmitApplicationRequest` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:6
- record `Intake.Worker.Endpoints.SubmitApplicationResponse` (public), src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:8
- interface `Intake.Worker.Publishing.IApplicationPublisher` (public), src/Intake.Worker/Publishing/IApplicationPublisher.cs:5
- class `Intake.Worker.Publishing.IntakeKafkaOptions` (public), src/Intake.Worker/Publishing/IntakeKafkaOptions.cs:3
- class `Intake.Worker.Publishing.IntakeTopics` (public), src/Intake.Worker/Publishing/IntakeKafkaOptions.cs:16
- class `Intake.Worker.Publishing.KafkaApplicationPublisher` (public), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:7
- class `Intake.Worker.Publishing.KafkaExtensions` (public), src/Intake.Worker/Publishing/KafkaExtensions.cs:8
- class `Intake.Worker.Publishing.LoggingApplicationPublisher` (public), src/Intake.Worker/Publishing/LoggingApplicationPublisher.cs:6
- class `Program` (public), src/Intake.Worker/Program.cs:17

## Used by other projects

- `Intake.Worker.Publishing.IApplicationPublisher`: 3 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Lab.Intake.Contracts.LeaseApplicationEnriched Intake.Worker.Endpoints.Enrichment.For(string applicationId, string companyNumber)`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationRequest.SubmitApplicationRequest(string ApplicantName, string CompanyNumber, string AssetType, decimal AssetValue, int TermMonths)`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationRequest`: 2 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Intake.Worker.Endpoints.SubmitApplicationResponse.ApplicationId`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.Enrichment`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Intake.Worker.Endpoints.SubmitApplicationResponse`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Program`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 6 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 4 of 5 links are unresolved; each has its reason in graph/links.ndjson.
- unresolved messaging link from messaging.publish at src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12: No subscriber of the same contract or of a contract with the same name was found.
- unresolved messaging link from messaging.publish at src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:15: No subscriber of the same contract or of a contract with the same name was found.

# Intake.Contracts

- Project: `src/Intake.Contracts/Intake.Contracts.csproj`
- Kind: library
- Assembly: Intake.Contracts
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Intake.sln`

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 0 consumed services)

None found.

## Configuration keys (0, values never stored)

None found.

## Project references

None.

## Direct packages

- Apache.Avro 1.12.2

## Types (2)

- class `Lab.Intake.Contracts.LeaseApplicationEnriched` (public), src/Intake.Contracts/LeaseApplicationEnriched.cs:7
- class `Lab.Intake.Contracts.LeaseApplicationSubmitted` (public), src/Intake.Contracts/LeaseApplicationSubmitted.cs:7

## Used by other projects

- `Lab.Intake.Contracts.LeaseApplicationSubmitted`: 16 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Lab.Intake.Contracts.LeaseApplicationEnriched`: 11 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationSubmitted.ApplicationId`: 5 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Avro.Schema Lab.Intake.Contracts.LeaseApplicationSubmitted._SCHEMA`: 3 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Lab.Intake.Contracts.LeaseApplicationSubmitted.LeaseApplicationSubmitted()`: 3 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationEnriched.ApplicationId`: 3 usages from `src/Intake.Worker/Intake.Worker.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationSubmitted.ApplicantName`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationSubmitted.AssetType`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `double Lab.Intake.Contracts.LeaseApplicationSubmitted.AssetValue`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationSubmitted.CompanyNumber`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `long Lab.Intake.Contracts.LeaseApplicationSubmitted.SubmittedAtUnixMs`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `int Lab.Intake.Contracts.LeaseApplicationSubmitted.TermMonths`: 2 usages from `src/Intake.Worker/Intake.Worker.csproj`, `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Avro.Schema Lab.Intake.Contracts.LeaseApplicationEnriched._SCHEMA`: 1 usages from `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj`
- `Lab.Intake.Contracts.LeaseApplicationEnriched.LeaseApplicationEnriched()`: 1 usages from `src/Intake.Worker/Intake.Worker.csproj`
- `string Lab.Intake.Contracts.LeaseApplicationEnriched.Sector`: 1 usages from `src/Intake.Worker/Intake.Worker.csproj`
- `int Lab.Intake.Contracts.LeaseApplicationEnriched.YearsTrading`: 1 usages from `src/Intake.Worker/Intake.Worker.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 6 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 4 of 5 links are unresolved; each has its reason in graph/links.ndjson.
None found.

# Message `Lab.Intake.Contracts.LeaseApplicationSubmitted`

- Identity: `dotnet:src/Intake.Contracts/Intake.Contracts.csproj:T:Lab.Intake.Contracts.LeaseApplicationSubmitted`
- Commit: `1e3322fa4e2dc1025ef2cdbd7b6cc9b7e7ce4a68`

## Publishers (1)

- `src/Intake.Worker/Intake.Worker.csproj` (kafka, topic `lease-applications-v1`, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12: No subscriber of the same contract or of a contract with the same name was found.

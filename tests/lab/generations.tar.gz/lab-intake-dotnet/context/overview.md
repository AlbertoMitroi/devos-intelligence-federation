# Repository overview

- Commit: `dbc7594e8f1ae1e3b490d86ce90b61e77f0b4838`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Intake.sln` (sln)

## Projects

| Project | Load mode | Target framework | Types | Card |
|---|---|---|---|---|
| `src/Intake.Contracts/Intake.Contracts.csproj` | semantic | net8.0 | 2 | [card](projects/Intake.Contracts-4152839c.md) |
| `src/Intake.Worker/Intake.Worker.csproj` | semantic | net8.0 | 11 | [card](projects/Intake.Worker-921a2cc6.md) |
| `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj` | semantic | net8.0 | 3 | [card](projects/Intake.Worker.Tests-7c0892c0.md) |

## Project references

```mermaid
flowchart LR
  p4152839cdb["Intake.Contracts"]
  p921a2cc6db["Intake.Worker"]
  p7c0892c0a8["Intake.Worker.Tests"]
  p921a2cc6db --> p4152839cdb
  p7c0892c0a8 --> p4152839cdb
  p7c0892c0a8 --> p921a2cc6db
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 6 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 4 of 5 links are unresolved; each has its reason in graph/links.ndjson.

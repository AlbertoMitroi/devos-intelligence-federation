# Repository overview

- Commit: `1e3322fa4e2dc1025ef2cdbd7b6cc9b7e7ce4a68`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Intake.sln` (sln)

## Services

| Project | Kind | Endpoints | Outgoing calls | Published | Subscribed | Card |
|---|---|---|---|---|---|---|
| `src/Intake.Worker/Intake.Worker.csproj` | service | 1 | 0 | 2 | 0 | [card](projects/Intake.Worker-921a2cc6.md) |

## Service map

None found.

4 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Contracts

- message `Lab.Intake.Contracts.LeaseApplicationEnriched`: 1 observations, [card](contracts/Lab.Intake.Contracts.LeaseApplicationEnriched-06a5662a.md)
- message `Lab.Intake.Contracts.LeaseApplicationSubmitted`: 1 observations, [card](contracts/Lab.Intake.Contracts.LeaseApplicationSubmitted-347a5373.md)

## Projects

| Project | Kind | Load mode | Target framework | Types | Card |
|---|---|---|---|---|---|
| `src/Intake.Contracts/Intake.Contracts.csproj` | library | semantic | net8.0 | 2 | [card](projects/Intake.Contracts-4152839c.md) |
| `src/Intake.Worker/Intake.Worker.csproj` | service | semantic | net8.0 | 11 | [card](projects/Intake.Worker-921a2cc6.md) |
| `tests/Intake.Worker.Tests/Intake.Worker.Tests.csproj` | test | semantic | net8.0 | 3 | [card](projects/Intake.Worker.Tests-7c0892c0.md) |

## Project references

```mermaid
flowchart LR
  n4152839cdb["Intake.Contracts"]
  n921a2cc6db["Intake.Worker"]
  n7c0892c0a8["Intake.Worker.Tests"]
  n921a2cc6db --> n4152839cdb
  n7c0892c0a8 --> n4152839cdb
  n7c0892c0a8 --> n921a2cc6db
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 6 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 4 of 5 links are unresolved; each has its reason in graph/links.ndjson.
- 4 unresolved links; each project card lists its own with the reason.

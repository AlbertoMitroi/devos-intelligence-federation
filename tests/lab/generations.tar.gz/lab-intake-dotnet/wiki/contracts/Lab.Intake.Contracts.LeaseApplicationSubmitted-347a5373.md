# Message `Lab.Intake.Contracts.LeaseApplicationSubmitted`

- Commit: `1e3322fa4e2dc1025ef2cdbd7b6cc9b7e7ce4a68`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Flow

```mermaid
flowchart LR
  n0d709154dc{{"Lab.Intake.Contracts.LeaseApplicationSubmitted"}}
  n921a2cc6db["Intake.Worker"]
  n921a2cc6db -->|"publishes"| n0d709154dc
```

## Publishers (1)

- `src/Intake.Worker/Intake.Worker.csproj` (kafka, topic `lease-applications-v1`, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12: No subscriber of the same contract or of a contract with the same name was found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> messages Lab.Intake.Contracts.LeaseApplicationSubmitted`

# Repository wiki

- Commit: `1e3322fa4e2dc1025ef2cdbd7b6cc9b7e7ce4a68`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Service map

No links between services were found.

None found.

4 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Services

- [Intake.Worker](services/Intake.Worker-921a2cc6.md) (service), `src/Intake.Worker/Intake.Worker.csproj`

## Contracts

- [Lab.Intake.Contracts.LeaseApplicationEnriched](contracts/Lab.Intake.Contracts.LeaseApplicationEnriched-06a5662a.md) (message, 1 observations)
- [Lab.Intake.Contracts.LeaseApplicationSubmitted](contracts/Lab.Intake.Contracts.LeaseApplicationSubmitted-347a5373.md) (message, 1 observations)

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> dump`

# Intake.Worker

- Commit: `1e3322fa4e2dc1025ef2cdbd7b6cc9b7e7ce4a68`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Intake.Worker/Intake.Worker.csproj`
- Kind: service
- Context card: [context/projects/Intake.Worker-921a2cc6.md](../../context/projects/Intake.Worker-921a2cc6.md)

## Neighbours

No links to or from other projects.

## Endpoints (1)

- POST `/intake/applications` → `unknown`, src/Intake.Worker/Endpoints/ApplicationEndpoints.cs:14

## Outgoing calls (0)

None found.

## Messages (2 published, 0 subscribed)

- publishes `dotnet:src/Intake.Contracts/Intake.Contracts.csproj:T:Lab.Intake.Contracts.LeaseApplicationSubmitted` (kafka, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:12; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Intake.Contracts/Intake.Contracts.csproj:T:Lab.Intake.Contracts.LeaseApplicationEnriched` (kafka, exact), src/Intake.Worker/Publishing/KafkaApplicationPublisher.cs:15; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Dependency injection (4 registrations, 3 consumed services)

Lifetimes: 1 scoped, 3 singleton.

- `T:System.TimeProvider` → `T:System.TimeProvider` (singleton), src/Intake.Worker/Program.cs:6
- `T:Intake.Worker.Publishing.IApplicationPublisher` → `T:Intake.Worker.Publishing.LoggingApplicationPublisher` (singleton, conditional), src/Intake.Worker/Publishing/KafkaExtensions.cs:16
- `T:Confluent.SchemaRegistry.ISchemaRegistryClient` → `T:Confluent.SchemaRegistry.CachedSchemaRegistryClient` (singleton), src/Intake.Worker/Publishing/KafkaExtensions.cs:20
- `T:Intake.Worker.Publishing.IApplicationPublisher` → `T:Intake.Worker.Publishing.KafkaApplicationPublisher` (scoped), src/Intake.Worker/Publishing/KafkaExtensions.cs:38

## Configuration keys (8, values never stored)

- `AllowedHosts`, src/Intake.Worker/appsettings.json:8
- `Kafka:BootstrapServers`, src/Intake.Worker/appsettings.Docker.json:3 and 1 more
- `Kafka:Enabled`, src/Intake.Worker/appsettings.Testing.json:3 and 1 more
- `Kafka:SchemaRegistryUrl`, src/Intake.Worker/appsettings.Docker.json:4 and 1 more
- `Kafka:Topics:Applications`, src/Intake.Worker/appsettings.json:14
- `Kafka:Topics:Enrichment`, src/Intake.Worker/appsettings.json:15
- `Logging:LogLevel:Default`, src/Intake.Worker/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Intake.Worker/appsettings.json:5

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Intake.Worker --kind entity`

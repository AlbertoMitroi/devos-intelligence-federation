# Lab.Core.Tests

- Commit: `cdc080f36a28785476a3f4d5ec963a81b539276d`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- Kind: test
- Context card: [context/projects/Lab.Core.Tests-d03fb0e9.md](../../context/projects/Lab.Core.Tests-d03fb0e9.md)

## Neighbours

```mermaid
flowchart LR
  n7bc5477ffa["Lab.Core.Clients.Pricing"]
  nd03fb0e915[["Lab.Core.Tests"]]
  nd03fb0e915 -->|"di ×1"| n7bc5477ffa
```

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 1 consumed services)

None found.

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Lab.Core.Tests --kind entity`

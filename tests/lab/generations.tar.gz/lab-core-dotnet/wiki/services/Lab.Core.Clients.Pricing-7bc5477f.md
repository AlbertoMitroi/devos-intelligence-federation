# Lab.Core.Clients.Pricing

- Commit: `cdc080f36a28785476a3f4d5ec963a81b539276d`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj`
- Kind: library
- Context card: [context/projects/Lab.Core.Clients.Pricing-7bc5477f.md](../../context/projects/Lab.Core.Clients.Pricing-7bc5477f.md)

## Neighbours

```mermaid
flowchart LR
  n7bc5477ffa[["Lab.Core.Clients.Pricing"]]
  nd03fb0e915["Lab.Core.Tests"]
  nd03fb0e915 -->|"di ×1"| n7bc5477ffa
```

## Endpoints (0)

None found.

## Outgoing calls (2)

- GET `/api/rate-cards/{}` (candidate), src/Lab.Core.Clients.Pricing/RateCardClient.cs:10; → unresolved: No typed-client registration with a base address was found for the calling client.
- GET `/api/residual-values` (exact), src/Lab.Core.Clients.Pricing/RateCardClient.cs:21; → unresolved: No typed-client registration with a base address was found for the calling client.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 2 consumed services)

Lifetimes: 1 transient.

- `T:Lab.Core.Clients.Pricing.IRateCardClient` → `T:Lab.Core.Clients.Pricing.RateCardClient` (transient), src/Lab.Core.Clients.Pricing/ServiceCollectionExtensions.cs:15

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Lab.Core.Clients.Pricing --kind entity`

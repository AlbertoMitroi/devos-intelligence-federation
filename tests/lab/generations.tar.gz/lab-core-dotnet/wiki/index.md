# Repository wiki

- Commit: `cdc080f36a28785476a3f4d5ec963a81b539276d`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Service map

```mermaid
flowchart LR
  n7bc5477ffa["Lab.Core.Clients.Pricing"]
  nd03fb0e915["Lab.Core.Tests"]
  nd03fb0e915 -->|"di ×1"| n7bc5477ffa
```

- `Lab.Core.Tests` → `Lab.Core.Clients.Pricing` via di: 1 link(s), strongest exact; for example tests/Lab.Core.Tests/RateCardClientTests.cs:31

2 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Services

- [Lab.Core.Clients.Pricing](services/Lab.Core.Clients.Pricing-7bc5477f.md) (library), `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj`
- [Lab.Core.Tests](services/Lab.Core.Tests-d03fb0e9.md) (test), `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`

## Contracts

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> dump`

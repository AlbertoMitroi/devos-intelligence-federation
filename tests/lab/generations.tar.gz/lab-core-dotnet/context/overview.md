# Repository overview

- Commit: `cdc080f36a28785476a3f4d5ec963a81b539276d`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Lab.Core.sln` (sln)

## Services

| Project | Kind | Endpoints | Outgoing calls | Published | Subscribed | Card |
|---|---|---|---|---|---|---|
| `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj` | library | 0 | 2 | 0 | 0 | [card](projects/Lab.Core.Clients.Pricing-7bc5477f.md) |
| `tests/Lab.Core.Tests/Lab.Core.Tests.csproj` | test | 0 | 0 | 0 | 0 | [card](projects/Lab.Core.Tests-d03fb0e9.md) |

## Service map

- `Lab.Core.Tests` → `Lab.Core.Clients.Pricing` via di: 1 link(s), strongest exact; for example tests/Lab.Core.Tests/RateCardClientTests.cs:31

2 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Contracts

None found.

## Projects

| Project | Kind | Load mode | Target framework | Types | Card |
|---|---|---|---|---|---|
| `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj` | library | semantic | net8.0 | 6 | [card](projects/Lab.Core.Clients.Pricing-7bc5477f.md) |
| `src/Lab.Core.MessageHubs/Lab.Core.MessageHubs.csproj` | library | semantic | net8.0 | 3 | [card](projects/Lab.Core.MessageHubs-bbcfa31b.md) |
| `src/Lab.Core.Transform.Bpmn/Lab.Core.Transform.Bpmn.csproj` | library | semantic | net8.0 | 7 | [card](projects/Lab.Core.Transform.Bpmn-6eec00ea.md) |
| `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj` | library | semantic | net8.0 | 20 | [card](projects/Lab.Core.Workflow.EventFlow-a26f2f18.md) |
| `tests/Lab.Core.Tests/Lab.Core.Tests.csproj` | test | semantic | net8.0 | 5 | [card](projects/Lab.Core.Tests-d03fb0e9.md) |

## Project references

```mermaid
flowchart LR
  n7bc5477ffa["Lab.Core.Clients.Pricing"]
  nbbcfa31b7e["Lab.Core.MessageHubs"]
  n6eec00eae9["Lab.Core.Transform.Bpmn"]
  na26f2f18b7["Lab.Core.Workflow.EventFlow"]
  nd03fb0e915["Lab.Core.Tests"]
  na26f2f18b7 --> n6eec00eae9
  nd03fb0e915 --> n7bc5477ffa
  nd03fb0e915 --> nbbcfa31b7e
  nd03fb0e915 --> n6eec00eae9
  nd03fb0e915 --> na26f2f18b7
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.
- 2 unresolved links; each project card lists its own with the reason.

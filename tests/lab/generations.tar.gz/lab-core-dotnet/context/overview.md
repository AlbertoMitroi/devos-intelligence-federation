# Repository overview

- Commit: `f7339fa11e6d1bdec98783093919f9170c23e293`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Lab.Core.sln` (sln)

## Projects

| Project | Load mode | Target framework | Types | Card |
|---|---|---|---|---|
| `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj` | semantic | net8.0 | 6 | [card](projects/Lab.Core.Clients.Pricing-7bc5477f.md) |
| `src/Lab.Core.MessageHubs/Lab.Core.MessageHubs.csproj` | semantic | net8.0 | 3 | [card](projects/Lab.Core.MessageHubs-bbcfa31b.md) |
| `src/Lab.Core.Transform.Bpmn/Lab.Core.Transform.Bpmn.csproj` | semantic | net8.0 | 7 | [card](projects/Lab.Core.Transform.Bpmn-6eec00ea.md) |
| `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj` | semantic | net8.0 | 20 | [card](projects/Lab.Core.Workflow.EventFlow-a26f2f18.md) |
| `tests/Lab.Core.Tests/Lab.Core.Tests.csproj` | semantic | net8.0 | 5 | [card](projects/Lab.Core.Tests-d03fb0e9.md) |

## Project references

```mermaid
flowchart LR
  p7bc5477ffa["Lab.Core.Clients.Pricing"]
  pbbcfa31b7e["Lab.Core.MessageHubs"]
  p6eec00eae9["Lab.Core.Transform.Bpmn"]
  pa26f2f18b7["Lab.Core.Workflow.EventFlow"]
  pd03fb0e915["Lab.Core.Tests"]
  pa26f2f18b7 --> p6eec00eae9
  pd03fb0e915 --> p7bc5477ffa
  pd03fb0e915 --> pbbcfa31b7e
  pd03fb0e915 --> p6eec00eae9
  pd03fb0e915 --> pa26f2f18b7
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.

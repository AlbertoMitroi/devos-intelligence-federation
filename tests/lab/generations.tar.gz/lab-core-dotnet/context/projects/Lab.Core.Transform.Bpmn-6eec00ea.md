# Lab.Core.Transform.Bpmn

- Project: `src/Lab.Core.Transform.Bpmn/Lab.Core.Transform.Bpmn.csproj`
- Assembly: Lab.Core.Transform.Bpmn
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Lab.Core.sln`

## Project references

None.

## Direct packages

None found.

## Types (7)

- class `Lab.Core.Transform.Bpmn.ActionMetaData` (public), src/Lab.Core.Transform.Bpmn/ProcessMetaData.cs:25
- class `Lab.Core.Transform.Bpmn.BpmnProcessLoader` (public), src/Lab.Core.Transform.Bpmn/BpmnProcessLoader.cs:10
- enum `Lab.Core.Transform.Bpmn.NodeKind` (public), src/Lab.Core.Transform.Bpmn/ProcessDefinition.cs:3
- record `Lab.Core.Transform.Bpmn.ProcessDefinition` (public), src/Lab.Core.Transform.Bpmn/ProcessDefinition.cs:17
- class `Lab.Core.Transform.Bpmn.ProcessMetaData` (public), src/Lab.Core.Transform.Bpmn/ProcessMetaData.cs:6
- record `Lab.Core.Transform.Bpmn.ProcessNode` (public), src/Lab.Core.Transform.Bpmn/ProcessDefinition.cs:13
- record `Lab.Core.Transform.Bpmn.SequenceFlow` (public), src/Lab.Core.Transform.Bpmn/ProcessDefinition.cs:15

## Used by other projects

- `Lab.Core.Transform.Bpmn.NodeKind`: 12 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.ProcessNode Lab.Core.Transform.Bpmn.ProcessDefinition.Node(string id)`: 6 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.IEnumerable<Lab.Core.Transform.Bpmn.SequenceFlow> Lab.Core.Transform.Bpmn.ProcessDefinition.Outgoing(string nodeId)`: 6 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `Lab.Core.Transform.Bpmn.ProcessDefinition Lab.Core.Transform.Bpmn.BpmnProcessLoader.LoadFile(string bpmnPath)`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.ProcessMetaData Lab.Core.Transform.Bpmn.ProcessDefinition.MetaData`: 4 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Transform.Bpmn.ProcessDefinition.ProcessId`: 4 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string? Lab.Core.Transform.Bpmn.ProcessNode.Lane`: 4 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.UserTask`: 3 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.BpmnProcessLoader.BpmnProcessLoader()`: 3 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Transform.Bpmn.ProcessNode.Id`: 3 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind Lab.Core.Transform.Bpmn.ProcessNode.Kind`: 3 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string? Lab.Core.Transform.Bpmn.SequenceFlow.Condition`: 3 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Transform.Bpmn.SequenceFlow.TargetRef`: 3 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `Lab.Core.Transform.Bpmn.BpmnProcessLoader`: 3 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.ExclusiveGateway`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.ServiceTask`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.StartEvent`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.IReadOnlyList<Lab.Core.Transform.Bpmn.ProcessDefinition> Lab.Core.Transform.Bpmn.BpmnProcessLoader.LoadDirectory(string directory)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.List<string> Lab.Core.Transform.Bpmn.ActionMetaData.AvailableDuring`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `System.Collections.Generic.IReadOnlyList<Lab.Core.Transform.Bpmn.SequenceFlow> Lab.Core.Transform.Bpmn.ProcessDefinition.Flows`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Transform.Bpmn.ProcessNode.Name`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `string Lab.Core.Transform.Bpmn.SequenceFlow.Id`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `bool Lab.Core.Transform.Bpmn.SequenceFlow.IsDefault`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.ProcessDefinition`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`, `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.SequenceFlow`: 2 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.EndEvent`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `Lab.Core.Transform.Bpmn.NodeKind.ParallelGateway`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `System.Collections.Generic.IReadOnlyList<Lab.Core.Transform.Bpmn.ProcessNode> Lab.Core.Transform.Bpmn.ProcessDefinition.Nodes`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Transform.Bpmn.ProcessNode Lab.Core.Transform.Bpmn.ProcessDefinition.StartEvent`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `System.Collections.Generic.Dictionary<string, Lab.Core.Transform.Bpmn.ActionMetaData> Lab.Core.Transform.Bpmn.ProcessMetaData.Actions`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `System.Collections.Generic.Dictionary<string, string> Lab.Core.Transform.Bpmn.ProcessMetaData.Participants`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- `System.Collections.Generic.List<string> Lab.Core.Transform.Bpmn.ProcessMetaData.StartedBy`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.Dictionary<string, string> Lab.Core.Transform.Bpmn.ProcessMetaData.Statuses`: 1 usages from `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.

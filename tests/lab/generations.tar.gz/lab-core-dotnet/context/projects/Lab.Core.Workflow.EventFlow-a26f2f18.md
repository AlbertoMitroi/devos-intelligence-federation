# Lab.Core.Workflow.EventFlow

- Project: `src/Lab.Core.Workflow.EventFlow/Lab.Core.Workflow.EventFlow.csproj`
- Assembly: Lab.Core.Workflow.EventFlow
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Lab.Core.sln`

## Project references

- `src/Lab.Core.Transform.Bpmn/Lab.Core.Transform.Bpmn.csproj`

## Direct packages

None found.

## Types (20)

- record `Lab.Core.Workflow.EventFlow.ActionExecuted` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:11
- record `Lab.Core.Workflow.EventFlow.CompletedTask` (public), src/Lab.Core.Workflow.EventFlow/FlowAggregate.cs:3
- class `Lab.Core.Workflow.EventFlow.EventFlowAnalyzer` (public), src/Lab.Core.Workflow.EventFlow/EventFlowAnalyzer.cs:19
- class `Lab.Core.Workflow.EventFlow.FlowAggregate` (public), src/Lab.Core.Workflow.EventFlow/FlowAggregate.cs:9
- record `Lab.Core.Workflow.EventFlow.FlowAnalysis` (public), src/Lab.Core.Workflow.EventFlow/EventFlowAnalyzer.cs:7
- record `Lab.Core.Workflow.EventFlow.FlowDataUpdated` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:13
- record `Lab.Core.Workflow.EventFlow.FlowEvent` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:4
- record `Lab.Core.Workflow.EventFlow.FlowFactRaised` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:18
- record `Lab.Core.Workflow.EventFlow.FlowStarted` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:6
- record `Lab.Core.Workflow.EventFlow.FlowStatusChanged` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:15
- class `Lab.Core.Workflow.EventFlow.FlowStatuses` (public), src/Lab.Core.Workflow.EventFlow/FlowAggregate.cs:58
- record `Lab.Core.Workflow.EventFlow.OpenTask` (public), src/Lab.Core.Workflow.EventFlow/EventFlowAnalyzer.cs:5
- class `Lab.Core.Workflow.EventFlow.Plugins.FlowContext` (public), src/Lab.Core.Workflow.EventFlow/Plugins/FlowContext.cs:4
- class `Lab.Core.Workflow.EventFlow.Plugins.FlowPluginConventions` (public), src/Lab.Core.Workflow.EventFlow/Plugins/FlowPluginConventions.cs:4
- interface `Lab.Core.Workflow.EventFlow.Plugins.IHandleAction` (public), src/Lab.Core.Workflow.EventFlow/Plugins/IHandleAction.cs:6
- interface `Lab.Core.Workflow.EventFlow.Plugins.IHandleNewFlow` (public), src/Lab.Core.Workflow.EventFlow/Plugins/IHandleNewFlow.cs:6
- interface `Lab.Core.Workflow.EventFlow.Plugins.IHandleServiceTask` (public), src/Lab.Core.Workflow.EventFlow/Plugins/IHandleServiceTask.cs:7
- interface `Lab.Core.Workflow.EventFlow.Plugins.IHandleUserTaskCommand<TCommand>` (public), src/Lab.Core.Workflow.EventFlow/Plugins/IHandleUserTaskCommand.cs:12
- interface `Lab.Core.Workflow.EventFlow.Plugins.IUserTaskCommand` (public), src/Lab.Core.Workflow.EventFlow/Plugins/IHandleUserTaskCommand.cs:4
- record `Lab.Core.Workflow.EventFlow.TaskCompleted` (public), src/Lab.Core.Workflow.EventFlow/FlowEvents.cs:9

## Used by other projects

- `Lab.Core.Workflow.EventFlow.FlowAnalysis Lab.Core.Workflow.EventFlow.EventFlowAnalyzer.Analyze(Lab.Core.Transform.Bpmn.ProcessDefinition process, Lab.Core.Workflow.EventFlow.FlowAggregate flow)`: 8 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.TaskCompleted`: 5 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.EventFlowAnalyzer.EventFlowAnalyzer()`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.TaskCompleted.TaskCompleted(System.Guid FlowId, string TaskId, string? Outcome, string? CompletedBy)`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.IReadOnlyList<Lab.Core.Workflow.EventFlow.OpenTask> Lab.Core.Workflow.EventFlow.FlowAnalysis.OpenTasks`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.FlowAnalysis.Status`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.EventFlowAnalyzer`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowStatuses`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Collections.Generic.IReadOnlyList<string> Lab.Core.Workflow.EventFlow.FlowAnalysis.AvailableActions`: 3 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.Plugins.FlowPluginConventions`: 3 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.FlowStatuses.Withdrawn`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `void Lab.Core.Workflow.EventFlow.FlowAggregate.Apply(Lab.Core.Workflow.EventFlow.FlowStarted e)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `void Lab.Core.Workflow.EventFlow.FlowAggregate.Apply(Lab.Core.Workflow.EventFlow.FlowStatusChanged e)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `void Lab.Core.Workflow.EventFlow.FlowAggregate.Apply(Lab.Core.Workflow.EventFlow.TaskCompleted e)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.Plugins.FlowPluginConventions.ActionNameOf(System.Type pluginType)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.Plugins.FlowPluginConventions.ProcessIdOf(System.Type pluginType)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.Plugins.FlowPluginConventions.TaskIdOf(System.Type pluginType)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `bool Lab.Core.Workflow.EventFlow.FlowAnalysis.IsCompleted`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowAggregate`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.FlowStatuses.InProgress`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.FlowStatuses.Started`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowAggregate.FlowAggregate()`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowStarted.FlowStarted(System.Guid FlowId, string ProcessId, System.Guid? ParentFlowId, string TriggeredBy, System.Collections.Generic.Dictionary<string, string> Data)`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowStatusChanged.FlowStatusChanged(System.Guid FlowId, string Status)`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.OpenTask.OpenTask(string TaskId, string Name, Lab.Core.Transform.Bpmn.NodeKind Kind, string? Lane, string? WorkTeam)`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Guid Lab.Core.Workflow.EventFlow.FlowAggregate.Id`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string? Lab.Core.Workflow.EventFlow.FlowAnalysis.ReachedEndEvent`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Guid Lab.Core.Workflow.EventFlow.FlowEvent.FlowId`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `string Lab.Core.Workflow.EventFlow.OpenTask.TaskId`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowStarted`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.FlowStatusChanged`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Workflow.EventFlow.OpenTask`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.

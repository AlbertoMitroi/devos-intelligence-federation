# Lab.Core.MessageHubs

- Project: `src/Lab.Core.MessageHubs/Lab.Core.MessageHubs.csproj`
- Kind: library
- Assembly: Lab.Core.MessageHubs
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Lab.Core.sln`

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 1 consumed services)

Lifetimes: 1 singleton.

- `T:Lab.Core.MessageHubs.IMessageHubUtility` → `T:Lab.Core.MessageHubs.MessageHubUtility`1` (singleton), src/Lab.Core.MessageHubs/MessageHubExtensions.cs:12

## Configuration keys (0, values never stored)

None found.

## Project references

None.

## Direct packages

None found.

## Types (3)

- interface `Lab.Core.MessageHubs.IMessageHubUtility` (public), src/Lab.Core.MessageHubs/IMessageHubUtility.cs:4
- class `Lab.Core.MessageHubs.MessageHubExtensions` (public), src/Lab.Core.MessageHubs/MessageHubExtensions.cs:6
- class `Lab.Core.MessageHubs.MessageHubUtility<THub>` (public), src/Lab.Core.MessageHubs/MessageHubUtility.cs:5

## Used by other projects

None found.

## What could not be determined

- `possible-runtime-targets` (partial): 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.
None found.

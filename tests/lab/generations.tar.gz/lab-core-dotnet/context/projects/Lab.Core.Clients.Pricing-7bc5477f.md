# Lab.Core.Clients.Pricing

- Project: `src/Lab.Core.Clients.Pricing/Lab.Core.Clients.Pricing.csproj`
- Assembly: Lab.Core.Clients.Pricing
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Lab.Core.sln`

## Project references

None.

## Direct packages

- Microsoft.Extensions.Http 8.0.1
- Microsoft.Extensions.Options.ConfigurationExtensions 8.0.0

## Types (6)

- interface `Lab.Core.Clients.Pricing.IRateCardClient` (public), src/Lab.Core.Clients.Pricing/IRateCardClient.cs:3
- record `Lab.Core.Clients.Pricing.RateCard` (public), src/Lab.Core.Clients.Pricing/Models.cs:3
- class `Lab.Core.Clients.Pricing.RateCardClientOptions` (public), src/Lab.Core.Clients.Pricing/RateCardClientOptions.cs:3
- record `Lab.Core.Clients.Pricing.ResidualValue` (public), src/Lab.Core.Clients.Pricing/Models.cs:5
- class `Lab.Core.Clients.Pricing.ServiceCollectionExtensions` (public), src/Lab.Core.Clients.Pricing/ServiceCollectionExtensions.cs:7
- class `Lab.Core.Clients.Pricing.RateCardClient` (internal), src/Lab.Core.Clients.Pricing/RateCardClient.cs:6

## Used by other projects

- `System.Threading.Tasks.Task<Lab.Core.Clients.Pricing.RateCard?> Lab.Core.Clients.Pricing.IRateCardClient.GetRateCardAsync(string productCode, [System.Threading.CancellationToken cancellationToken])`: 4 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `System.Threading.Tasks.Task<Lab.Core.Clients.Pricing.ResidualValue?> Lab.Core.Clients.Pricing.IRateCardClient.GetResidualValueAsync(string assetType, int termMonths, [System.Threading.CancellationToken cancellationToken])`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Microsoft.Extensions.DependencyInjection.IHttpClientBuilder Lab.Core.Clients.Pricing.ServiceCollectionExtensions.AddRateCardClient(Microsoft.Extensions.DependencyInjection.IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Clients.Pricing.IRateCardClient`: 2 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Clients.Pricing.RateCard.RateCard(string ProductCode, decimal BaseRatePercent, int MinTermMonths, int MaxTermMonths)`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Clients.Pricing.ResidualValue.ResidualValue(string AssetType, int TermMonths, decimal Percent)`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Clients.Pricing.RateCard`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`
- `Lab.Core.Clients.Pricing.ResidualValue`: 1 usages from `tests/Lab.Core.Tests/Lab.Core.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 3 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 2 of 3 links are unresolved; each has its reason in graph/links.ndjson.

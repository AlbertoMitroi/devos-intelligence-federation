# Repository overview

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Leasing.sln` (sln)

## Services

| Project | Kind | Endpoints | Outgoing calls | Published | Subscribed | Card |
|---|---|---|---|---|---|---|
| `src/Leasing.AppHost/Leasing.AppHost.csproj` | host | 0 | 0 | 0 | 0 | [card](projects/Leasing.AppHost-5f225ba8.md) |
| `src/Leasing.AppServices/Leasing.AppServices.csproj` | service | 0 | 0 | 5 | 10 | [card](projects/Leasing.AppServices-4df53c14.md) |
| `src/Leasing.Host/Leasing.Host.csproj` | service | 16 | 0 | 0 | 0 | [card](projects/Leasing.Host-fb73ed4c.md) |
| `src/Leasing.Pricing/Leasing.Pricing.csproj` | library | 0 | 0 | 0 | 0 | [card](projects/Leasing.Pricing-2dabd545.md) |
| `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` | test | 0 | 0 | 11 | 0 | [card](projects/Leasing.AppServices.Tests-d9c14fb2.md) |
| `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj` | test | 0 | 0 | 0 | 0 | [card](projects/Leasing.Pricing.Tests-3430966f.md) |
| `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj` | host | 0 | 0 | 0 | 0 | [card](projects/Leasing.QuoteBackfill-7ebcf743.md) |

## Service map

- `Leasing.AppServices` → `Leasing.AppServices.Tests` via di: 9 link(s), strongest exact; for example src/Leasing.AppServices/Flows/Plugins/Quote/PriceQuoteHandler.cs:7
- `Leasing.Host` → `Leasing.AppServices` via inprocess: 16 link(s), strongest exact; for example src/Leasing.Host/Controllers/V1/LeasesController.cs:36
- `Leasing.AppServices.Tests` → `Leasing.AppServices` via di: 3 link(s), strongest exact; for example tests/Leasing.AppServices.Tests/FlowEngineTests.cs:53
- `Leasing.AppServices.Tests` → `Leasing.AppServices` via inprocess: 11 link(s), strongest candidate; for example tests/Leasing.AppServices.Tests/FlowEngineTests.cs:37
- `Leasing.Pricing.Tests` → `Leasing.Pricing` via di: 1 link(s), strongest exact; for example tests/Leasing.Pricing.Tests/QuotePricingTests.cs:24

13 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Contracts

- message `Lab.Intake.Contracts.LeaseApplicationEnriched`: 2 observations, [card](contracts/Lab.Intake.Contracts.LeaseApplicationEnriched-0a0e20ac.md)
- message `Lab.Intake.Contracts.LeaseApplicationSubmitted`: 2 observations, [card](contracts/Lab.Intake.Contracts.LeaseApplicationSubmitted-059c4893.md)
- message `Lab.Leasing.Contracts.LeaseContractActivated`: 1 observations, [card](contracts/Lab.Leasing.Contracts.LeaseContractActivated-f88dce34.md)
- message `Leasing.AppServices.Flows.Commands.AcceptQuoteCommand`: 1 observations, [card](contracts/Leasing.AppServices.Flows.Commands.AcceptQuoteCommand-712e879b.md)
- message `Leasing.AppServices.Flows.Commands.AssessRiskCommand`: 2 observations, [card](contracts/Leasing.AppServices.Flows.Commands.AssessRiskCommand-8c6d7b9c.md)
- message `Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand`: 2 observations, [card](contracts/Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand-f313eac5.md)
- message `Leasing.AppServices.Flows.Commands.ReviewApplicationCommand`: 3 observations, [card](contracts/Leasing.AppServices.Flows.Commands.ReviewApplicationCommand-5c1f9235.md)
- message `Leasing.AppServices.Flows.Commands.SignContractCommand`: 1 observations, [card](contracts/Leasing.AppServices.Flows.Commands.SignContractCommand-cb9211b6.md)
- message `Leasing.AppServices.Flows.Commands.StartFlowCommand`: 2 observations, [card](contracts/Leasing.AppServices.Flows.Commands.StartFlowCommand-47a65666.md)
- message `Leasing.AppServices.Messaging.CreditCheckRequested`: 3 observations, [card](contracts/Leasing.AppServices.Messaging.CreditCheckRequested-79a3c186.md)
- message `Leasing.AppServices.Messaging.CreditCheckResponse`: 3 observations, [card](contracts/Leasing.AppServices.Messaging.CreditCheckResponse-49333fd9.md)
- message `Leasing.AppServices.Messaging.FlowEventsAppended`: 3 observations, [card](contracts/Leasing.AppServices.Messaging.FlowEventsAppended-afcc77b9.md)
- message `Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox`: 1 observations, [card](contracts/Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox-40ed9308.md)

## Projects

| Project | Kind | Load mode | Target framework | Types | Card |
|---|---|---|---|---|---|
| `.` | library | syntax | unknown | 0 | [card](projects/repository-cdb4ee2a.md) |
| `src/Leasing.AppHost/Leasing.AppHost.csproj` | host | semantic | net8.0 | 2 | [card](projects/Leasing.AppHost-5f225ba8.md) |
| `src/Leasing.AppServices/Leasing.AppServices.csproj` | service | semantic | net8.0 | 87 | [card](projects/Leasing.AppServices-4df53c14.md) |
| `src/Leasing.Host/Leasing.Host.csproj` | service | semantic | net8.0 | 16 | [card](projects/Leasing.Host-fb73ed4c.md) |
| `src/Leasing.Pricing/Leasing.Pricing.csproj` | library | semantic | net8.0 | 6 | [card](projects/Leasing.Pricing-2dabd545.md) |
| `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` | test | semantic | net8.0 | 5 | [card](projects/Leasing.AppServices.Tests-d9c14fb2.md) |
| `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj` | test | semantic | net8.0 | 2 | [card](projects/Leasing.Host.Tests-057357eb.md) |
| `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj` | test | semantic | net8.0 | 3 | [card](projects/Leasing.Pricing.Tests-3430966f.md) |
| `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj` | host | semantic | net8.0 | 0 | [card](projects/Leasing.QuoteBackfill-7ebcf743.md) |

## Project references

```mermaid
flowchart LR
  n4df53c14e5["Leasing.AppServices"]
  nfb73ed4c0c["Leasing.Host"]
  n2dabd5456b["Leasing.Pricing"]
  nd9c14fb217["Leasing.AppServices.Tests"]
  n057357eb14["Leasing.Host.Tests"]
  n3430966f3e["Leasing.Pricing.Tests"]
  n4df53c14e5 --> n2dabd5456b
  nfb73ed4c0c --> n4df53c14e5
  nfb73ed4c0c --> n2dabd5456b
  nd9c14fb217 --> n4df53c14e5
  nd9c14fb217 --> n2dabd5456b
  n057357eb14 --> n4df53c14e5
  n057357eb14 --> nfb73ed4c0c
  n057357eb14 --> n2dabd5456b
  n3430966f3e --> n2dabd5456b
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 13 of 88 links are unresolved; each has its reason in graph/links.ndjson.
- 13 unresolved links; each project card lists its own with the reason.

# Repository overview

- Commit: `48d2aa0b14df091b23275534d35dcbc77a3fd933`
- Engine: dotnet-intelligence 0.1.0, Roslyn 5.9.0
- Status: complete

## Solutions

- `Leasing.sln` (sln)

## Projects

| Project | Load mode | Target framework | Types | Card |
|---|---|---|---|---|
| `src/Leasing.AppHost/Leasing.AppHost.csproj` | semantic | net8.0 | 2 | [card](projects/Leasing.AppHost-5f225ba8.md) |
| `src/Leasing.AppServices/Leasing.AppServices.csproj` | semantic | net8.0 | 87 | [card](projects/Leasing.AppServices-4df53c14.md) |
| `src/Leasing.Host/Leasing.Host.csproj` | semantic | net8.0 | 16 | [card](projects/Leasing.Host-fb73ed4c.md) |
| `src/Leasing.Pricing/Leasing.Pricing.csproj` | semantic | net8.0 | 6 | [card](projects/Leasing.Pricing-2dabd545.md) |
| `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` | semantic | net8.0 | 5 | [card](projects/Leasing.AppServices.Tests-d9c14fb2.md) |
| `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj` | semantic | net8.0 | 2 | [card](projects/Leasing.Host.Tests-057357eb.md) |
| `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj` | semantic | net8.0 | 3 | [card](projects/Leasing.Pricing.Tests-3430966f.md) |
| `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj` | semantic | net8.0 | 0 | [card](projects/Leasing.QuoteBackfill-7ebcf743.md) |

## Project references

```mermaid
flowchart LR
  p4df53c14e5["Leasing.AppServices"]
  pfb73ed4c0c["Leasing.Host"]
  p2dabd5456b["Leasing.Pricing"]
  pd9c14fb217["Leasing.AppServices.Tests"]
  p057357eb14["Leasing.Host.Tests"]
  p3430966f3e["Leasing.Pricing.Tests"]
  p4df53c14e5 --> p2dabd5456b
  pfb73ed4c0c --> p4df53c14e5
  pfb73ed4c0c --> p2dabd5456b
  pd9c14fb217 --> p4df53c14e5
  pd9c14fb217 --> p2dabd5456b
  p057357eb14 --> p4df53c14e5
  p057357eb14 --> pfb73ed4c0c
  p057357eb14 --> p2dabd5456b
  p3430966f3e --> p2dabd5456b
```

## What could not be determined

- `possible-runtime-targets` (partial): 1 occurrences, for example `repository`: 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 1 occurrences, for example `repository`: 14 of 78 links are unresolved; each has its reason in graph/links.ndjson.

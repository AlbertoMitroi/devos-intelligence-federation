# Message `Leasing.AppServices.Flows.Commands.StartFlowCommand`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.StartFlowCommand`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (2)

- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:163; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:51; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:163: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:163 is itself candidate
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:51: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:51 is itself candidate

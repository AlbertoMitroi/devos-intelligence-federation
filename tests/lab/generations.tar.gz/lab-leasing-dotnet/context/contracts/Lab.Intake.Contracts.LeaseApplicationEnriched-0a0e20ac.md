# Message `Lab.Intake.Contracts.LeaseApplicationEnriched`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Intake.Contracts.LeaseApplicationEnriched`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (0)

None found.

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (kafka, topic `lease-application-enrichment-v1`, exact), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationEnrichedConsumer.cs:11
- `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (kafka, topic `lease-application-enrichment-v1`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:107

## What could not be determined

Every observation of this contract is linked.

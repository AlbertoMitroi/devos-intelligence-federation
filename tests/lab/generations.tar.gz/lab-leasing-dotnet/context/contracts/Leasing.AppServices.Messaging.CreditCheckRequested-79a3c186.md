# Message `Leasing.AppServices.Messaging.CreditCheckRequested`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckRequested`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:13; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `credit-check-requests`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:50
- `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `credit-check-requests`, exact), src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10

## What could not be determined

Every observation of this contract is linked.

# Message `Lab.Leasing.Contracts.LeaseContractActivated`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Leasing.Contracts.LeaseContractActivated`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (kafka, topic `leasing-contracts-v1`, exact), src/Leasing.AppServices/Messaging/Kafka/KafkaLeaseContractPublisher.cs:11; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at src/Leasing.AppServices/Messaging/Kafka/KafkaLeaseContractPublisher.cs:11: No subscriber of the same contract or of a contract with the same name was found.

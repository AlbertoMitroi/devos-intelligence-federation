# Message `Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:22; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at src/Leasing.AppServices/Messaging/BusAdapters.cs:22: No subscriber of the same contract or of a contract with the same name was found.

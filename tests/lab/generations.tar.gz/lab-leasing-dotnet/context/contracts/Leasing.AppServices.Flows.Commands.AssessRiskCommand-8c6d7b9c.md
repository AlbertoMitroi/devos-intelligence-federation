# Message `Leasing.AppServices.Flows.Commands.AssessRiskCommand`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.AssessRiskCommand`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (2)

- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:103; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:147; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:103: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:103 is itself candidate
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:147: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:147 is itself candidate

# Message `Leasing.AppServices.Messaging.CreditCheckResponse`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckResponse`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:16; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Consumers/CreditCheckResponseConsumer.cs:9

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Consumers.CreditCheckResponseConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `leasing-credit-check-responses`, exact), src/Leasing.AppServices/Messaging/Consumers/CreditCheckResponseConsumer.cs:9
- `T:Leasing.AppServices.Messaging.Consumers.CreditCheckResponseConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `leasing-credit-check-responses`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:46

## What could not be determined

Every observation of this contract is linked.

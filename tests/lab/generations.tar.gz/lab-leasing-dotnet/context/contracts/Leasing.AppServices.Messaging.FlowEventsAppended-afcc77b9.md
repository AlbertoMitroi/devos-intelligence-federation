# Message `Leasing.AppServices.Messaging.FlowEventsAppended`

- Identity: `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.FlowEventsAppended`
- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Consumers/FlowEventsAppendedConsumer.cs:6

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Consumers.FlowEventsAppendedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `leasing-ordered-projection-messages`, exact), src/Leasing.AppServices/Messaging/Consumers/FlowEventsAppendedConsumer.cs:6
- `T:Leasing.AppServices.Messaging.Consumers.FlowEventsAppendedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `leasing-ordered-projection-messages`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:47

## What could not be determined

Every observation of this contract is linked.

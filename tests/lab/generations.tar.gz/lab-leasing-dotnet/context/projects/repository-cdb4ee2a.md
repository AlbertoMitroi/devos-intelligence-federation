# repository

- Project: `.`
- Kind: library
- Assembly: unknown
- Load mode: syntax (Files outside every project (BPMN, Terraform), read without a compilation.)
- Target frameworks: ; analyzed: none
- SDK: unknown
- Solutions: 

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 0 consumed services)

None found.

## Configuration keys (0, values never stored)

None found.

## Project references

None.

## Direct packages

None found.

## Types (0)

None found.

## Used by other projects

None found.

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 13 of 88 links are unresolved; each has its reason in graph/links.ndjson.
None found.

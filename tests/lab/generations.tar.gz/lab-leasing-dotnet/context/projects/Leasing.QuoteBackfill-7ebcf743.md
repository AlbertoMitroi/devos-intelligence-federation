# Leasing.QuoteBackfill

- Project: `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj`
- Kind: host
- Assembly: Leasing.QuoteBackfill
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Entry points

- top-level statements, tools/Leasing.QuoteBackfill/Program.cs:10

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 1 consumed services)

None found.

## Configuration keys (1, values never stored)

- `Clients:Pricing:BaseAddress`, tools/Leasing.QuoteBackfill/appsettings.json:4

## Project references

None.

## Direct packages

- Microsoft.Extensions.Hosting 8.0.1
- Pricing.Client 1.0.0

## Types (0)

None found.

## Used by other projects

None found.

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 13 of 88 links are unresolved; each has its reason in graph/links.ndjson.
None found.

# Leasing.QuoteBackfill

- Project: `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj`
- Assembly: Leasing.QuoteBackfill
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Project references

None.

## Direct packages

- Microsoft.Extensions.Hosting 8.0.1
- Pricing.Client 1.0.0

## Types (0)

None found.

## Entry points

- top-level statements

## Used by other projects

None found.

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 14 of 78 links are unresolved; each has its reason in graph/links.ndjson.

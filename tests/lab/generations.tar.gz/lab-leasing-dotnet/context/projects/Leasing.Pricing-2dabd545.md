# Leasing.Pricing

- Project: `src/Leasing.Pricing/Leasing.Pricing.csproj`
- Kind: library
- Assembly: Leasing.Pricing
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 2 consumed services)

Lifetimes: 1 scoped.

- `T:Leasing.Pricing.IQuotePricing` → `T:Leasing.Pricing.QuotePricingService` (scoped), src/Leasing.Pricing/PricingModuleExtensions.cs:20

## Configuration keys (0, values never stored)

None found.

## Project references

None.

## Direct packages

- Lab.Core.Clients.Pricing 1.0.0
- Microsoft.Extensions.Http.Resilience 8.10.0
- Pricing.Client 1.1.0

## Types (6)

- interface `Leasing.Pricing.IQuotePricing` (public), src/Leasing.Pricing/IQuotePricing.cs:4
- class `Leasing.Pricing.PricingModuleExtensions` (public), src/Leasing.Pricing/PricingModuleExtensions.cs:10
- class `Leasing.Pricing.PricingUnavailableException` (public), src/Leasing.Pricing/QuotePricingService.cs:27
- record `Leasing.Pricing.QuotePricingRequest` (public), src/Leasing.Pricing/QuotePricingResult.cs:3
- record `Leasing.Pricing.QuotePricingResult` (public), src/Leasing.Pricing/QuotePricingResult.cs:5
- class `Leasing.Pricing.QuotePricingService` (internal), src/Leasing.Pricing/QuotePricingService.cs:6

## Used by other projects

- `System.Threading.Tasks.Task<Leasing.Pricing.QuotePricingResult> Leasing.Pricing.IQuotePricing.PriceAsync(Leasing.Pricing.QuotePricingRequest request, System.Threading.CancellationToken cancellationToken)`: 6 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Leasing.Pricing.IQuotePricing`: 6 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Leasing.Pricing.QuotePricingRequest`: 6 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Leasing.Pricing.QuotePricingResult`: 6 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `System.Threading.Tasks.Task<Leasing.Pricing.QuotePricingResult> Leasing.Pricing.IQuotePricing.RepriceAsync(System.Guid pricingQuoteId, int termMonths, System.Threading.CancellationToken cancellationToken)`: 4 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Microsoft.Extensions.DependencyInjection.IServiceCollection Leasing.Pricing.PricingModuleExtensions.AddPricingModule(Microsoft.Extensions.DependencyInjection.IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)`: 4 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Leasing.Pricing.QuotePricingRequest.QuotePricingRequest(string ProductCode, string AssetType, decimal AssetValue, int TermMonths)`: 4 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `Leasing.Pricing.QuotePricingResult.QuotePricingResult(System.Guid PricingQuoteId, decimal MonthlyPayment, decimal RatePercent, decimal ResidualPercent, int TermMonths)`: 3 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `decimal Leasing.Pricing.QuotePricingResult.MonthlyPayment`: 2 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `int Leasing.Pricing.QuotePricingResult.TermMonths`: 2 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`, `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- `int Leasing.Pricing.QuotePricingRequest.TermMonths`: 1 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `System.Guid Leasing.Pricing.QuotePricingResult.PricingQuoteId`: 1 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`
- `decimal Leasing.Pricing.QuotePricingResult.RatePercent`: 1 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`
- `decimal Leasing.Pricing.QuotePricingResult.ResidualPercent`: 1 usages from `src/Leasing.AppServices/Leasing.AppServices.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 13 of 88 links are unresolved; each has its reason in graph/links.ndjson.
None found.

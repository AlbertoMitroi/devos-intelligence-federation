# Leasing.AppServices

- Project: `src/Leasing.AppServices/Leasing.AppServices.csproj`
- Assembly: Leasing.AppServices
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Project references

- `src/Leasing.Pricing/Leasing.Pricing.csproj`

## Direct packages

- Apache.Avro 1.12.2
- Confluent.SchemaRegistry.Serdes.Avro 2.16.0
- Elastic.Clients.Elasticsearch 8.19.27
- Lab.Core.MessageHubs 1.0.0
- Lab.Core.Transform.Bpmn 1.0.0
- Lab.Core.Workflow.EventFlow 1.0.0
- Marten 8.38.2
- MassTransit 8.5.12
- MassTransit.Azure.ServiceBus.Core 8.5.12
- MassTransit.Kafka 8.5.12
- MassTransit.RabbitMQ 8.5.12
- MediatR 12.5.0

## Types (87)

- class `Lab.Intake.Contracts.LeaseApplicationEnriched` (public), src/Leasing.AppServices/Avro/LeaseApplicationEnriched.cs:7
- class `Lab.Intake.Contracts.LeaseApplicationSubmitted` (public), src/Leasing.AppServices/Avro/LeaseApplicationSubmitted.cs:7
- class `Lab.Leasing.Contracts.LeaseContractActivated` (public), src/Leasing.AppServices/Avro/LeaseContractActivated.cs:7
- class `Leasing.AppServices.EventStore.EventStoreExtensions` (public), src/Leasing.AppServices/EventStore/EventStoreExtensions.cs:14
- class `Leasing.AppServices.EventStore.LeaseDocument` (public), src/Leasing.AppServices/EventStore/LeaseDocument.cs:4
- class `Leasing.AppServices.EventStore.MartenFlowStore` (public), src/Leasing.AppServices/EventStore/MartenFlowStore.cs:9
- class `Leasing.AppServices.EventStore.Projections.FlowTimeline` (public), src/Leasing.AppServices/EventStore/Projections/FlowTimelineProjection.cs:6
- class `Leasing.AppServices.EventStore.Projections.FlowTimelineProjection` (public), src/Leasing.AppServices/EventStore/Projections/FlowTimelineProjection.cs:16
- class `Leasing.AppServices.EventStore.Projections.PortfolioSummary` (public), src/Leasing.AppServices/EventStore/Projections/PortfolioSummaryProjection.cs:6
- class `Leasing.AppServices.EventStore.Projections.PortfolioSummaryProjection` (public), src/Leasing.AppServices/EventStore/Projections/PortfolioSummaryProjection.cs:18
- record `Leasing.AppServices.Flows.Commands.AcceptQuoteCommand` (public), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:10
- record `Leasing.AppServices.Flows.Commands.AssessRiskCommand` (public), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:8
- record `Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:10
- class `Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommandHandler` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24
- record `Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (public), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:6
- record `Leasing.AppServices.Flows.Commands.SignContractCommand` (public), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:12
- record `Leasing.AppServices.Flows.Commands.StartFlowCommand` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:6
- class `Leasing.AppServices.Flows.Commands.StartFlowCommandHandler` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:12
- record `Leasing.AppServices.Flows.Commands.UpdateFlowDataCommand` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:8
- class `Leasing.AppServices.Flows.Commands.UpdateFlowDataCommandHandler` (public), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:18
- class `Leasing.AppServices.Flows.Commands.UserTaskCommandHandlers` (public), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- class `Leasing.AppServices.Flows.FlowConflictException` (public), src/Leasing.AppServices/Flows/FlowView.cs:22
- class `Leasing.AppServices.Flows.FlowDataKeys` (public), src/Leasing.AppServices/Flows/FlowDataKeys.cs:4
- class `Leasing.AppServices.Flows.FlowEngine` (public), src/Leasing.AppServices/Flows/FlowEngine.cs:12
- class `Leasing.AppServices.Flows.FlowNotFoundException` (public), src/Leasing.AppServices/Flows/FlowView.cs:20
- record `Leasing.AppServices.Flows.FlowView` (public), src/Leasing.AppServices/Flows/FlowView.cs:6
- interface `Leasing.AppServices.Flows.IFlowChangeNotifier` (public), src/Leasing.AppServices/Flows/IFlowStore.cs:17
- interface `Leasing.AppServices.Flows.IFlowStore` (public), src/Leasing.AppServices/Flows/IFlowStore.cs:6
- class `Leasing.AppServices.Flows.PluginRegistry` (public), src/Leasing.AppServices/Flows/PluginRegistry.cs:11
- class `Leasing.AppServices.Flows.Plugins.Application.ApplicationNewFlowHandler` (public), src/Leasing.AppServices/Flows/Plugins/Application/ApplicationNewFlowHandler.cs:5
- class `Leasing.AppServices.Flows.Plugins.Application.ReviewApplicationHandler` (public), src/Leasing.AppServices/Flows/Plugins/Application/ReviewApplicationHandler.cs:6
- class `Leasing.AppServices.Flows.Plugins.Application.ValidateApplicationHandler` (public), src/Leasing.AppServices/Flows/Plugins/Application/ValidateApplicationHandler.cs:6
- class `Leasing.AppServices.Flows.Plugins.Application.WithdrawActionHandler` (public), src/Leasing.AppServices/Flows/Plugins/Application/WithdrawActionHandler.cs:6
- class `Leasing.AppServices.Flows.Plugins.Assessment.AssessRiskHandler` (public), src/Leasing.AppServices/Flows/Plugins/Assessment/AssessRiskHandler.cs:6
- class `Leasing.AppServices.Flows.Plugins.Assessment.AssessmentNewFlowHandler` (public), src/Leasing.AppServices/Flows/Plugins/Assessment/AssessmentNewFlowHandler.cs:5
- class `Leasing.AppServices.Flows.Plugins.Assessment.RequestCreditCheckHandler` (public), src/Leasing.AppServices/Flows/Plugins/Assessment/RequestCreditCheckHandler.cs:6
- class `Leasing.AppServices.Flows.Plugins.Lease.ActivateLeaseHandler` (public), src/Leasing.AppServices/Flows/Plugins/Lease/ActivateLeaseHandler.cs:9
- class `Leasing.AppServices.Flows.Plugins.Lease.LeaseNewFlowHandler` (public), src/Leasing.AppServices/Flows/Plugins/Lease/LeaseNewFlowHandler.cs:5
- class `Leasing.AppServices.Flows.Plugins.Lease.PrepareContractHandler` (public), src/Leasing.AppServices/Flows/Plugins/Lease/PrepareContractHandler.cs:5
- class `Leasing.AppServices.Flows.Plugins.Lease.SignContractHandler` (public), src/Leasing.AppServices/Flows/Plugins/Lease/SignContractHandler.cs:6

47 more types omitted; see graph/relations.ndjson, kind `declares`, from `prj:0e075aef184c2fb3e9ea4f8823df4703`.

## Used by other projects

- `Leasing.AppServices.Flows.FlowView`: 13 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.FlowDataKeys`: 12 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `string Leasing.AppServices.Flows.FlowView.Status`: 7 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand.ExecuteFlowActionCommand(System.Guid FlowId, string ActionName, System.Collections.Generic.IReadOnlyDictionary<string, string> Parameters, string? UserId)`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.ReviewApplicationCommand.ReviewApplicationCommand(System.Guid FlowId, bool Approve, string? Comment, string? UserId)`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `System.Threading.Tasks.Task<Leasing.AppServices.Flows.FlowView> Leasing.AppServices.Flows.FlowEngine.Get(System.Guid flowId, System.Threading.CancellationToken cancellationToken)`: 4 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Queries.GetFlowQuery.GetFlowQuery(System.Guid FlowId, string ProcessId)`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `Leasing.AppServices.Flows.Queries.SearchFlowsQuery.SearchFlowsQuery(string ProcessId, string? Status, string? Text)`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `System.Collections.Generic.IReadOnlyList<Lab.Core.Workflow.EventFlow.OpenTask> Leasing.AppServices.Flows.FlowView.OpenTasks`: 4 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `System.Collections.Generic.IReadOnlyCollection<Lab.Core.Transform.Bpmn.ProcessDefinition> Leasing.AppServices.Flows.ProcessCatalog.All`: 4 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.ReviewApplicationCommand`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Queries.GetFlowQuery`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `Leasing.AppServices.Flows.Queries.SearchFlowsQuery`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `Leasing.AppServices.Search.FlowReadModel`: 4 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `string Leasing.AppServices.Flows.FlowDataKeys.TermMonths`: 3 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.AssessRiskCommand.AssessRiskCommand(System.Guid FlowId, string RiskGrade, string? UserId)`: 3 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.EventStore.LeaseDocument`: 3 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.AssessRiskCommand`: 3 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.PluginRegistry`: 3 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `string Leasing.AppServices.Flows.FlowDataKeys.MonthlyPayment`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `string Leasing.AppServices.Messaging.Kafka.LeaseApplicationSubmittedConsumer.Trigger`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.AcceptQuoteCommand.AcceptQuoteCommand(System.Guid FlowId, bool Accept, string? UserId)`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.SignContractCommand.SignContractCommand(System.Guid FlowId, string SignedBy, string? UserId)`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.StartFlowCommand.StartFlowCommand(string Trigger, System.Guid? FlowId, System.Collections.Generic.IReadOnlyDictionary<string, string> Data)`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Microsoft.Extensions.DependencyInjection.IServiceCollection Leasing.AppServices.ServicesExtensions.AddLeasingAppServices(Microsoft.Extensions.DependencyInjection.IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`
- `Microsoft.Extensions.DependencyInjection.IServiceCollection Leasing.AppServices.ServicesExtensions.AddLeasingFlowEngine(Microsoft.Extensions.DependencyInjection.IServiceCollection services)`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `System.Collections.Generic.IReadOnlyDictionary<string, string> Leasing.AppServices.Flows.FlowView.Data`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.AcceptQuoteCommand`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.SignContractCommand`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.Commands.StartFlowCommand`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.FlowConflictException`: 2 usages from `src/Leasing.Host/Leasing.Host.csproj`, `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.FlowEngine`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.IFlowChangeNotifier`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Flows.IFlowStore`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Messaging.Kafka.LeaseApplicationSubmittedConsumer`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Ports.ICreditCheckGateway`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Ports.ILeaseContractPublisher`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Ports.ILeaseDocuments`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- `Leasing.AppServices.Ports.INoticeOutbox`: 2 usages from `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`

29 more symbols omitted; see graph/relations.ndjson, kinds `references` and `calls_declared_target`.

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 14 of 78 links are unresolved; each has its reason in graph/links.ndjson.

# Leasing.Host

- Project: `src/Leasing.Host/Leasing.Host.csproj`
- Kind: service
- Assembly: Leasing.Host
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Entry points

- top-level statements, src/Leasing.Host/Program.cs:11

## Endpoints (17)

- GET `/v1/admin/portfolio` → `M:Leasing.Host.Controllers.V1.AdminController.Portfolio(System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AdminController.cs:14
- GET `/v1/applications` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Search(System.String,System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:20
- GET `/v1/applications/{}` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:24
- POST `/v1/applications/{}/review` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Review(System.Guid,Leasing.Host.Controllers.V1.ReviewApplicationRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:28
- POST `/v1/applications/{}/actions/withdraw` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Withdraw(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:33
- GET `/v1/assessments` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Search(System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:20
- GET `/v1/assessments/{}` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:24
- POST `/v1/assessments/{}/assess` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Assess(System.Guid,Leasing.Host.Controllers.V1.AssessRiskRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:28
- GET `/v1/leases` → `M:Leasing.Host.Controllers.V1.LeasesController.Search(System.String,System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:21
- GET `/v1/leases/{}` → `M:Leasing.Host.Controllers.V1.LeasesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:25
- GET `/v1/leases/{}/document` → `M:Leasing.Host.Controllers.V1.LeasesController.GetDocument(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:29
- POST `/v1/leases/{}/sign` → `M:Leasing.Host.Controllers.V1.LeasesController.Sign(System.Guid,Leasing.Host.Controllers.V1.SignContractRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:33
- GET `/v1/quotes` → `M:Leasing.Host.Controllers.V1.QuotesController.Search(System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:23
- GET `/v1/quotes/{}` → `M:Leasing.Host.Controllers.V1.QuotesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:27
- POST `/v1/quotes/{}/accept` → `M:Leasing.Host.Controllers.V1.QuotesController.Accept(System.Guid,Leasing.Host.Controllers.V1.AcceptQuoteRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:31
- POST `/v1/quotes/{}/recalculate` → `M:Leasing.Host.Controllers.V1.QuotesController.Recalculate(System.Guid,Leasing.Host.Controllers.V1.RecalculateQuoteRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:36
- hub `T:Leasing.Host.Hubs.LeasingHub` at `/hubs/leasing`, src/Leasing.Host/Program.cs:42

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## In-process dispatch (16)

- sends `T:Leasing.AppServices.Flows.Queries.GetPortfolioSummaryQuery` (mediatr), src/Leasing.Host/Controllers/V1/AdminController.cs:16; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:22; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:26; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:36; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:22; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:26; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.AssessRiskCommand` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:23; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:27; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Queries.GetLeaseDocumentQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12
- sends `T:Leasing.AppServices.Flows.Commands.SignContractCommand` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:36; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:25; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:29; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.AcceptQuoteCommand` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:34; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:39; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24

## Dependency injection (0 registrations, 6 consumed services)

None found.

## Configuration keys (36, values never stored)

- `AllowedHosts`, src/Leasing.Host/appsettings.json:8
- `Authentication:LocalDev:Audience`, src/Leasing.Host/appsettings.Docker.json:16 and 1 more
- `Authentication:LocalDev:Issuer`, src/Leasing.Host/appsettings.Docker.json:15 and 1 more
- `Authentication:LocalDev:SigningKey`, src/Leasing.Host/appsettings.Docker.json:17 and 1 more
- `AzureAd:Audience`, src/Leasing.Host/appsettings.json:13
- `AzureAd:ClientId`, src/Leasing.Host/appsettings.json:12
- `AzureAd:Instance`, src/Leasing.Host/appsettings.json:10
- `AzureAd:TenantId`, src/Leasing.Host/appsettings.json:11
- `Clients:Pricing:BaseAddress`, src/Leasing.Host/appsettings.Dev.json:4 and 2 more
- `Clients:RateCards:BaseAddress`, src/Leasing.Host/appsettings.Dev.json:7 and 2 more
- `ConnectionStrings:LeasingDb` (secret), src/Leasing.Host/appsettings.Docker.json:3 and 2 more
- `Cors:Origins:0`, src/Leasing.Host/appsettings.Dev.json:30 and 2 more
- `Cors:Origins:1`, src/Leasing.Host/appsettings.Docker.json:34
- `Elasticsearch:Indexes:Flows`, src/Leasing.Host/appsettings.json:56
- `Elasticsearch:Url`, src/Leasing.Host/appsettings.Dev.json:27 and 2 more
- `Kafka:BootstrapServers`, src/Leasing.Host/appsettings.Dev.json:23 and 2 more
- `Kafka:ConsumerGroup`, src/Leasing.Host/appsettings.json:46
- `Kafka:Enabled`, src/Leasing.Host/appsettings.json:43
- `Kafka:SchemaRegistryUrl`, src/Leasing.Host/appsettings.Dev.json:24 and 2 more
- `Kafka:Topics:Applications`, src/Leasing.Host/appsettings.json:48
- `Kafka:Topics:Contracts`, src/Leasing.Host/appsettings.json:50
- `Kafka:Topics:Enrichment`, src/Leasing.Host/appsettings.json:49
- `Logging:LogLevel:Default`, src/Leasing.Host/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Leasing.Host/appsettings.json:5
- `Messaging:AzureServiceBusHost:ConnectionString` (secret), src/Leasing.Host/appsettings.Dev.json:13
- `Messaging:CreditBureauSimulator`, src/Leasing.Host/appsettings.Docker.json:24 and 2 more
- `Messaging:Queues:CreditCheckRequests`, src/Leasing.Host/appsettings.Dev.json:16 and 1 more
- `Messaging:Queues:CreditCheckResponses`, src/Leasing.Host/appsettings.Dev.json:17 and 1 more
- `Messaging:Queues:NoticeOutbox`, src/Leasing.Host/appsettings.Dev.json:18 and 1 more
- `Messaging:Queues:Projections`, src/Leasing.Host/appsettings.Dev.json:19 and 1 more
- `Messaging:RabbitMqHost:Host`, src/Leasing.Host/appsettings.Docker.json:22 and 1 more
- `Messaging:RabbitMqHost:Password` (secret), src/Leasing.Host/appsettings.json:32
- `Messaging:RabbitMqHost:Username`, src/Leasing.Host/appsettings.json:31
- `Messaging:RabbitMqHost:VirtualHost`, src/Leasing.Host/appsettings.json:30
- `Messaging:Transport`, src/Leasing.Host/appsettings.Dev.json:11 and 1 more
- `WorkTeams:UnderwritingTeam:Members:0`, src/Leasing.Host/appsettings.Local.json:16

## Project references

- `src/Leasing.AppServices/Leasing.AppServices.csproj`
- `src/Leasing.Pricing/Leasing.Pricing.csproj`

## Direct packages

- Microsoft.AspNetCore.Authentication.JwtBearer 8.0.11
- Microsoft.Azure.SignalR 1.33.1
- Microsoft.Identity.Web 3.16.0
- Swashbuckle.AspNetCore 6.9.0

## Types (16)

- class `Leasing.Host.Authorization.AuthenticationExtensions` (public), src/Leasing.Host/Authorization/AuthenticationExtensions.cs:9
- class `Leasing.Host.Authorization.Policies` (public), src/Leasing.Host/Authorization/Policies.cs:3
- class `Leasing.Host.Authorization.Roles` (public), src/Leasing.Host/Authorization/Policies.cs:10
- record `Leasing.Host.Controllers.V1.AcceptQuoteRequest` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:13
- class `Leasing.Host.Controllers.V1.AdminController` (public), src/Leasing.Host/Controllers/V1/AdminController.cs:12
- class `Leasing.Host.Controllers.V1.ApplicationsController` (public), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:16
- record `Leasing.Host.Controllers.V1.AssessRiskRequest` (public), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:12
- class `Leasing.Host.Controllers.V1.AssessmentsController` (public), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:16
- class `Leasing.Host.Controllers.V1.LeasesController` (public), src/Leasing.Host/Controllers/V1/LeasesController.cs:17
- class `Leasing.Host.Controllers.V1.LeasingControllerBase` (public), src/Leasing.Host/Controllers/V1/LeasingControllerBase.cs:10
- class `Leasing.Host.Controllers.V1.QuotesController` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:19
- record `Leasing.Host.Controllers.V1.RecalculateQuoteRequest` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:15
- record `Leasing.Host.Controllers.V1.ReviewApplicationRequest` (public), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:12
- record `Leasing.Host.Controllers.V1.SignContractRequest` (public), src/Leasing.Host/Controllers/V1/LeasesController.cs:13
- class `Leasing.Host.Hubs.LeasingHub` (public), src/Leasing.Host/Hubs/LeasingHub.cs:12
- class `Program` (public), src/Leasing.Host/Program.cs:47

## Used by other projects

- `Leasing.Host.Authorization.Policies`: 3 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `Leasing.Host.Controllers.V1.LeasingControllerBase`: 2 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.Admin`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.DefaultRead`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.DefaultWrite`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `Leasing.Host.Hubs.LeasingHub`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 13 of 88 links are unresolved; each has its reason in graph/links.ndjson.
None found.

# Leasing.Host

- Project: `src/Leasing.Host/Leasing.Host.csproj`
- Assembly: Leasing.Host
- Load mode: semantic (loaded)
- Target frameworks: net8.0; analyzed: net8.0
- SDK: 8.0.427
- Solutions: `Leasing.sln`

## Project references

- `src/Leasing.AppServices/Leasing.AppServices.csproj`
- `src/Leasing.Pricing/Leasing.Pricing.csproj`

## Direct packages

- Microsoft.AspNetCore.Authentication.JwtBearer 8.0.11
- Microsoft.Azure.SignalR 1.33.1
- Microsoft.Identity.Web 3.16.0
- Swashbuckle.AspNetCore 6.9.0

## Types (16)

- class `Leasing.Host.Authorization.AuthenticationExtensions` (public), src/Leasing.Host/Authorization/AuthenticationExtensions.cs:9
- class `Leasing.Host.Authorization.Policies` (public), src/Leasing.Host/Authorization/Policies.cs:3
- class `Leasing.Host.Authorization.Roles` (public), src/Leasing.Host/Authorization/Policies.cs:10
- record `Leasing.Host.Controllers.V1.AcceptQuoteRequest` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:13
- class `Leasing.Host.Controllers.V1.AdminController` (public), src/Leasing.Host/Controllers/V1/AdminController.cs:12
- class `Leasing.Host.Controllers.V1.ApplicationsController` (public), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:16
- record `Leasing.Host.Controllers.V1.AssessRiskRequest` (public), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:12
- class `Leasing.Host.Controllers.V1.AssessmentsController` (public), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:16
- class `Leasing.Host.Controllers.V1.LeasesController` (public), src/Leasing.Host/Controllers/V1/LeasesController.cs:17
- class `Leasing.Host.Controllers.V1.LeasingControllerBase` (public), src/Leasing.Host/Controllers/V1/LeasingControllerBase.cs:10
- class `Leasing.Host.Controllers.V1.QuotesController` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:19
- record `Leasing.Host.Controllers.V1.RecalculateQuoteRequest` (public), src/Leasing.Host/Controllers/V1/QuotesController.cs:15
- record `Leasing.Host.Controllers.V1.ReviewApplicationRequest` (public), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:12
- record `Leasing.Host.Controllers.V1.SignContractRequest` (public), src/Leasing.Host/Controllers/V1/LeasesController.cs:13
- class `Leasing.Host.Hubs.LeasingHub` (public), src/Leasing.Host/Hubs/LeasingHub.cs:12
- class `Program` (public), src/Leasing.Host/Program.cs:47

## Entry points

- top-level statements

## Used by other projects

- `Leasing.Host.Authorization.Policies`: 3 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `Leasing.Host.Controllers.V1.LeasingControllerBase`: 2 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.Admin`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.DefaultRead`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `string Leasing.Host.Authorization.Policies.DefaultWrite`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`
- `Leasing.Host.Hubs.LeasingHub`: 1 usages from `tests/Leasing.Host.Tests/Leasing.Host.Tests.csproj`

## What could not be determined

- `possible-runtime-targets` (partial): 48 possible runtime targets were inferred from interface and virtual calls to implementations known in this repository; implementations outside the repository are not known.
- `unresolved-links` (partial): 14 of 78 links are unresolved; each has its reason in graph/links.ndjson.

# Repository wiki

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Service map

```mermaid
flowchart LR
  n4df53c14e5["Leasing.AppServices"]
  nfb73ed4c0c["Leasing.Host"]
  n2dabd5456b["Leasing.Pricing"]
  nd9c14fb217["Leasing.AppServices.Tests"]
  n3430966f3e["Leasing.Pricing.Tests"]
  n4df53c14e5 -->|"di ×9"| nd9c14fb217
  nfb73ed4c0c -->|"inprocess ×16"| n4df53c14e5
  nd9c14fb217 -->|"di ×3"| n4df53c14e5
  nd9c14fb217 -.->|"inprocess ×11, candidate"| n4df53c14e5
  n3430966f3e -->|"di ×1"| n2dabd5456b
```

- `Leasing.AppServices` → `Leasing.AppServices.Tests` via di: 9 link(s), strongest exact; for example src/Leasing.AppServices/Flows/Plugins/Quote/PriceQuoteHandler.cs:7
- `Leasing.Host` → `Leasing.AppServices` via inprocess: 16 link(s), strongest exact; for example src/Leasing.Host/Controllers/V1/LeasesController.cs:36
- `Leasing.AppServices.Tests` → `Leasing.AppServices` via di: 3 link(s), strongest exact; for example tests/Leasing.AppServices.Tests/FlowEngineTests.cs:53
- `Leasing.AppServices.Tests` → `Leasing.AppServices` via inprocess: 11 link(s), strongest candidate; for example tests/Leasing.AppServices.Tests/FlowEngineTests.cs:37
- `Leasing.Pricing.Tests` → `Leasing.Pricing` via di: 1 link(s), strongest exact; for example tests/Leasing.Pricing.Tests/QuotePricingTests.cs:24

13 link(s) are unresolved (no target found); each has its reason in graph/links.ndjson and on the card of its project.

## Services

- [Leasing.AppHost](services/Leasing.AppHost-5f225ba8.md) (host), `src/Leasing.AppHost/Leasing.AppHost.csproj`
- [Leasing.AppServices](services/Leasing.AppServices-4df53c14.md) (service), `src/Leasing.AppServices/Leasing.AppServices.csproj`
- [Leasing.Host](services/Leasing.Host-fb73ed4c.md) (service), `src/Leasing.Host/Leasing.Host.csproj`
- [Leasing.Pricing](services/Leasing.Pricing-2dabd545.md) (library), `src/Leasing.Pricing/Leasing.Pricing.csproj`
- [Leasing.AppServices.Tests](services/Leasing.AppServices.Tests-d9c14fb2.md) (test), `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- [Leasing.Pricing.Tests](services/Leasing.Pricing.Tests-3430966f.md) (test), `tests/Leasing.Pricing.Tests/Leasing.Pricing.Tests.csproj`
- [Leasing.QuoteBackfill](services/Leasing.QuoteBackfill-7ebcf743.md) (host), `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj`

## Contracts

- [Lab.Intake.Contracts.LeaseApplicationEnriched](contracts/Lab.Intake.Contracts.LeaseApplicationEnriched-0a0e20ac.md) (message, 2 observations)
- [Lab.Intake.Contracts.LeaseApplicationSubmitted](contracts/Lab.Intake.Contracts.LeaseApplicationSubmitted-059c4893.md) (message, 2 observations)
- [Lab.Leasing.Contracts.LeaseContractActivated](contracts/Lab.Leasing.Contracts.LeaseContractActivated-f88dce34.md) (message, 1 observations)
- [Leasing.AppServices.Flows.Commands.AcceptQuoteCommand](contracts/Leasing.AppServices.Flows.Commands.AcceptQuoteCommand-712e879b.md) (message, 1 observations)
- [Leasing.AppServices.Flows.Commands.AssessRiskCommand](contracts/Leasing.AppServices.Flows.Commands.AssessRiskCommand-8c6d7b9c.md) (message, 2 observations)
- [Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand](contracts/Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand-f313eac5.md) (message, 2 observations)
- [Leasing.AppServices.Flows.Commands.ReviewApplicationCommand](contracts/Leasing.AppServices.Flows.Commands.ReviewApplicationCommand-5c1f9235.md) (message, 3 observations)
- [Leasing.AppServices.Flows.Commands.SignContractCommand](contracts/Leasing.AppServices.Flows.Commands.SignContractCommand-cb9211b6.md) (message, 1 observations)
- [Leasing.AppServices.Flows.Commands.StartFlowCommand](contracts/Leasing.AppServices.Flows.Commands.StartFlowCommand-47a65666.md) (message, 2 observations)
- [Leasing.AppServices.Messaging.CreditCheckRequested](contracts/Leasing.AppServices.Messaging.CreditCheckRequested-79a3c186.md) (message, 3 observations)
- [Leasing.AppServices.Messaging.CreditCheckResponse](contracts/Leasing.AppServices.Messaging.CreditCheckResponse-49333fd9.md) (message, 3 observations)
- [Leasing.AppServices.Messaging.FlowEventsAppended](contracts/Leasing.AppServices.Messaging.FlowEventsAppended-afcc77b9.md) (message, 3 observations)
- [Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox](contracts/Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox-40ed9308.md) (message, 1 observations)

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> dump`

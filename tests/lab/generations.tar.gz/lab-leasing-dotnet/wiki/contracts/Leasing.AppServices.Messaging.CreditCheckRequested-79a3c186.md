# Message `Leasing.AppServices.Messaging.CreditCheckRequested`

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Flow

```mermaid
flowchart LR
  ne2cd853201{{"Leasing.AppServices.Messaging.CreditCheckRequested"}}
  n4df53c14e5["Leasing.AppServices"]
  n4df53c14e5 -->|"publishes"| ne2cd853201
  ne2cd853201 -->|"consumed by"| n4df53c14e5
```

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:13; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `credit-check-requests`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:50
- `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, queue `credit-check-requests`, exact), src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10

## What could not be determined

Every observation of this contract is linked.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> messages Leasing.AppServices.Messaging.CreditCheckRequested`

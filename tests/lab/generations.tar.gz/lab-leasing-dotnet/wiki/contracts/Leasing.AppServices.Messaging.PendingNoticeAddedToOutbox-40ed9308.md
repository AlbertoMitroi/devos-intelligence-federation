# Message `Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox`

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Flow

```mermaid
flowchart LR
  n8e1b88e368{{"Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox"}}
  n4df53c14e5["Leasing.AppServices"]
  n4df53c14e5 -->|"publishes"| n8e1b88e368
```

## Publishers (1)

- `src/Leasing.AppServices/Leasing.AppServices.csproj` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:22; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at src/Leasing.AppServices/Messaging/BusAdapters.cs:22: No subscriber of the same contract or of a contract with the same name was found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> messages Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox`

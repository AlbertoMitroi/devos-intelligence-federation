# Message `Leasing.AppServices.Flows.Commands.ReviewApplicationCommand`

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Flow

```mermaid
flowchart LR
  n784c4a0d43{{"Leasing.AppServices.Flows.Commands.ReviewApplicationCommand"}}
  nd9c14fb217["Leasing.AppServices.Tests"]
  nd9c14fb217 -.->|"publishes, candidate"| n784c4a0d43
```

## Publishers (3)

- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:137; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:146; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:96; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## Subscribers (0)

None found.

## What could not be determined

- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:137: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:137 is itself candidate
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:146: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:146 is itself candidate
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:96: No subscriber of the same contract or of a contract with the same name was found.
- messaging.publish at tests/Leasing.AppServices.Tests/FlowEngineTests.cs:96 is itself candidate

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> messages Leasing.AppServices.Flows.Commands.ReviewApplicationCommand`

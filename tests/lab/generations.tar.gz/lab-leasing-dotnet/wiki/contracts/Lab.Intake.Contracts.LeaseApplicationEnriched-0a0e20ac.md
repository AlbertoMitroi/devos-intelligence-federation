# Message `Lab.Intake.Contracts.LeaseApplicationEnriched`

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete

## Flow

```mermaid
flowchart LR
  n55d5a83370{{"Lab.Intake.Contracts.LeaseApplicationEnriched"}}
  n4df53c14e5["Leasing.AppServices"]
  n55d5a83370 -->|"consumed by"| n4df53c14e5
```

## Publishers (0)

None found.

## Subscribers (2)

- `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (kafka, topic `lease-application-enrichment-v1`, exact), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationEnrichedConsumer.cs:11
- `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` in `src/Leasing.AppServices/Leasing.AppServices.csproj` (kafka, topic `lease-application-enrichment-v1`, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:107

## What could not be determined

Every observation of this contract is linked.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> messages Lab.Intake.Contracts.LeaseApplicationEnriched`

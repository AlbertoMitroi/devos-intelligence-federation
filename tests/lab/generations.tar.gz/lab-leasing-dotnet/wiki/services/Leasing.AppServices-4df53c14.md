# Leasing.AppServices

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Leasing.AppServices/Leasing.AppServices.csproj`
- Kind: service
- Context card: [context/projects/Leasing.AppServices-4df53c14.md](../../context/projects/Leasing.AppServices-4df53c14.md)

## Neighbours

```mermaid
flowchart LR
  n4df53c14e5[["Leasing.AppServices"]]
  nfb73ed4c0c["Leasing.Host"]
  nd9c14fb217["Leasing.AppServices.Tests"]
  n4df53c14e5 -->|"di ×9"| nd9c14fb217
  nfb73ed4c0c -->|"inprocess ×16"| n4df53c14e5
  nd9c14fb217 -->|"di ×3"| n4df53c14e5
  nd9c14fb217 -.->|"inprocess ×11, candidate"| n4df53c14e5
```

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (5 published, 10 subscribed)

- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckRequested` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:13; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.PendingNoticeAddedToOutbox` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:22; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.FlowEventsAppended` (transport unknown, exact), src/Leasing.AppServices/Messaging/BusAdapters.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Consumers/FlowEventsAppendedConsumer.cs:6
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Leasing.Contracts.LeaseContractActivated` (kafka, exact), src/Leasing.AppServices/Messaging/Kafka/KafkaLeaseContractPublisher.cs:11; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckResponse` (transport unknown, exact), src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:16; → exact `Leasing.AppServices` src/Leasing.AppServices/Messaging/Consumers/CreditCheckResponseConsumer.cs:9
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckResponse` in `T:Leasing.AppServices.Messaging.Consumers.CreditCheckResponseConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/Consumers/CreditCheckResponseConsumer.cs:9
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.FlowEventsAppended` in `T:Leasing.AppServices.Messaging.Consumers.FlowEventsAppendedConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/Consumers/FlowEventsAppendedConsumer.cs:6
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Intake.Contracts.LeaseApplicationEnriched` in `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` (kafka, exact), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationEnrichedConsumer.cs:11
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Intake.Contracts.LeaseApplicationSubmitted` in `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationSubmittedConsumer` (kafka, exact), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationSubmittedConsumer.cs:11
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Intake.Contracts.LeaseApplicationSubmitted` in `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationSubmittedConsumer` (kafka, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:106
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Lab.Intake.Contracts.LeaseApplicationEnriched` in `T:Leasing.AppServices.Messaging.Kafka.LeaseApplicationEnrichedConsumer` (kafka, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:107
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckResponse` in `T:Leasing.AppServices.Messaging.Consumers.CreditCheckResponseConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:46
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.FlowEventsAppended` in `T:Leasing.AppServices.Messaging.Consumers.FlowEventsAppendedConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:47
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckRequested` in `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:50
- subscribes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Messaging.CreditCheckRequested` in `T:Leasing.AppServices.Messaging.Simulators.CreditBureauSimulatorConsumer` (transport unknown, exact), src/Leasing.AppServices/Messaging/Simulators/CreditBureauSimulatorConsumer.cs:10

## In-process dispatch (14)

- sends `T:Leasing.AppServices.Flows.Commands.UpdateFlowDataCommand` (mediatr), src/Leasing.AppServices/Messaging/Consumers/CreditCheckResponseConsumer.cs:12; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:18
- sends `T:Leasing.AppServices.Flows.Commands.UpdateFlowDataCommand` (mediatr), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationEnrichedConsumer.cs:14; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:18
- sends `T:Leasing.AppServices.Flows.Commands.StartFlowCommand` (mediatr), src/Leasing.AppServices/Messaging/Kafka/LeaseApplicationSubmittedConsumer.cs:18; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:12
- handles `T:Leasing.AppServices.Flows.Commands.StartFlowCommand` in `T:Leasing.AppServices.Flows.Commands.StartFlowCommandHandler` (mediatr), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:12
- handles `T:Leasing.AppServices.Flows.Commands.UpdateFlowDataCommand` in `T:Leasing.AppServices.Flows.Commands.UpdateFlowDataCommandHandler` (mediatr), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:18
- handles `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` in `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommandHandler` (mediatr), src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24
- handles `T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` in `T:Leasing.AppServices.Flows.Commands.UserTaskCommandHandlers` (mediatr), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- handles `T:Leasing.AppServices.Flows.Commands.SignContractCommand` in `T:Leasing.AppServices.Flows.Commands.UserTaskCommandHandlers` (mediatr), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- handles `T:Leasing.AppServices.Flows.Commands.AcceptQuoteCommand` in `T:Leasing.AppServices.Flows.Commands.UserTaskCommandHandlers` (mediatr), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- handles `T:Leasing.AppServices.Flows.Commands.AssessRiskCommand` in `T:Leasing.AppServices.Flows.Commands.UserTaskCommandHandlers` (mediatr), src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- handles `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` in `T:Leasing.AppServices.Flows.Queries.GetFlowQueryHandler` (mediatr), src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- handles `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` in `T:Leasing.AppServices.Flows.Queries.SearchFlowsQueryHandler` (mediatr), src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- handles `T:Leasing.AppServices.Flows.Queries.GetLeaseDocumentQuery` in `T:Leasing.AppServices.Flows.Queries.PortfolioQueryHandlers` (mediatr), src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12
- handles `T:Leasing.AppServices.Flows.Queries.GetPortfolioSummaryQuery` in `T:Leasing.AppServices.Flows.Queries.PortfolioQueryHandlers` (mediatr), src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12

## Dependency injection (18 registrations, 50 consumed services)

Lifetimes: 11 scoped, 7 singleton.

- `T:Leasing.AppServices.EventStore.MartenFlowStore` → `T:Leasing.AppServices.EventStore.MartenFlowStore` (scoped), src/Leasing.AppServices/EventStore/EventStoreExtensions.cs:38
- `T:Leasing.AppServices.Flows.IFlowStore` → `T:Leasing.AppServices.EventStore.MartenFlowStore` (scoped), src/Leasing.AppServices/EventStore/EventStoreExtensions.cs:39
- `T:Leasing.AppServices.Ports.ILeaseDocuments` → `T:Leasing.AppServices.EventStore.MartenFlowStore` (scoped), src/Leasing.AppServices/EventStore/EventStoreExtensions.cs:40
- `T:Leasing.AppServices.Ports.ICreditCheckGateway` → `T:Leasing.AppServices.Messaging.BusCreditCheckGateway` (scoped), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:30
- `T:Leasing.AppServices.Ports.INoticeOutbox` → `T:Leasing.AppServices.Messaging.BusNoticeOutbox` (scoped), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:31
- `T:Leasing.AppServices.Flows.IFlowChangeNotifier` → `T:Leasing.AppServices.Messaging.BusFlowChangeNotifier` (scoped), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:32
- `T:Confluent.SchemaRegistry.ISchemaRegistryClient` → `T:Confluent.SchemaRegistry.CachedSchemaRegistryClient` (singleton, conditional), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:36
- `T:Leasing.AppServices.Ports.ILeaseContractPublisher` → `T:Leasing.AppServices.Messaging.Kafka.KafkaLeaseContractPublisher` (scoped, conditional), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:37
- `T:Leasing.AppServices.Ports.ILeaseContractPublisher` → `T:Leasing.AppServices.Messaging.Kafka.DisabledLeaseContractPublisher` (singleton, conditional), src/Leasing.AppServices/Messaging/MessagingExtensions.cs:41
- `T:Elastic.Clients.Elasticsearch.ElasticsearchClient` → `T:Elastic.Clients.Elasticsearch.ElasticsearchClient` (singleton), src/Leasing.AppServices/Search/ElasticsearchFlowSearch.cs:51
- `T:Leasing.AppServices.Search.IFlowSearch` → `T:Leasing.AppServices.Search.ElasticsearchFlowSearch` (scoped), src/Leasing.AppServices/Search/ElasticsearchFlowSearch.cs:56
- `T:System.TimeProvider` → `T:System.TimeProvider` (singleton), src/Leasing.AppServices/ServicesExtensions.cs:31
- `T:Lab.Core.Transform.Bpmn.BpmnProcessLoader` → `T:Lab.Core.Transform.Bpmn.BpmnProcessLoader` (singleton), src/Leasing.AppServices/ServicesExtensions.cs:32
- `T:Leasing.AppServices.Flows.ProcessCatalog` → `T:Leasing.AppServices.Flows.ProcessCatalog` (singleton), src/Leasing.AppServices/ServicesExtensions.cs:33
- `T:Lab.Core.Workflow.EventFlow.EventFlowAnalyzer` → `T:Lab.Core.Workflow.EventFlow.EventFlowAnalyzer` (singleton), src/Leasing.AppServices/ServicesExtensions.cs:34
- `T:Leasing.AppServices.Flows.PluginRegistry` → `T:Leasing.AppServices.Flows.PluginRegistry` (scoped), src/Leasing.AppServices/ServicesExtensions.cs:35
- `T:Leasing.AppServices.Flows.FlowEngine` → `T:Leasing.AppServices.Flows.FlowEngine` (scoped), src/Leasing.AppServices/ServicesExtensions.cs:36
- `T:Leasing.AppServices.Projections.FlowProjectionService` → `T:Leasing.AppServices.Projections.FlowProjectionService` (scoped), src/Leasing.AppServices/ServicesExtensions.cs:37

## Data (3)

- table `mt_doc_leasedocument` ← `T:Leasing.AppServices.EventStore.LeaseDocument` (marten-document), src/Leasing.AppServices/EventStore/EventStoreExtensions.cs:33
- table `mt_doc_flowaggregate` ← `T:Lab.Core.Workflow.EventFlow.FlowAggregate` (marten-document), src/Leasing.AppServices/EventStore/MartenFlowStore.cs:12
- table `mt_doc_portfoliosummary` ← `T:Leasing.AppServices.EventStore.Projections.PortfolioSummary` (marten-document), src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:17

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Leasing.AppServices --kind entity`

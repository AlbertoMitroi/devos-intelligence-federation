# Leasing.QuoteBackfill

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `tools/Leasing.QuoteBackfill/Leasing.QuoteBackfill.csproj`
- Kind: host
- Context card: [context/projects/Leasing.QuoteBackfill-7ebcf743.md](../../context/projects/Leasing.QuoteBackfill-7ebcf743.md)

## Neighbours

No links to or from other projects.

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (0 registrations, 1 consumed services)

None found.

## Configuration keys (1, values never stored)

- `Clients:Pricing:BaseAddress`, tools/Leasing.QuoteBackfill/appsettings.json:4

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Leasing.QuoteBackfill --kind entity`

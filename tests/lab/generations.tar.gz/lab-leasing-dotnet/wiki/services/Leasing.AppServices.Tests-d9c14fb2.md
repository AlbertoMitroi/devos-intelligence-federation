# Leasing.AppServices.Tests

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `tests/Leasing.AppServices.Tests/Leasing.AppServices.Tests.csproj`
- Kind: test
- Context card: [context/projects/Leasing.AppServices.Tests-d9c14fb2.md](../../context/projects/Leasing.AppServices.Tests-d9c14fb2.md)

## Neighbours

```mermaid
flowchart LR
  n4df53c14e5["Leasing.AppServices"]
  nd9c14fb217[["Leasing.AppServices.Tests"]]
  n4df53c14e5 -->|"di ×9"| nd9c14fb217
  nd9c14fb217 -->|"di ×3"| n4df53c14e5
  nd9c14fb217 -.->|"inprocess ×11, candidate"| n4df53c14e5
```

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (11 published, 0 subscribed)

- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.AssessRiskCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:103; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.AcceptQuoteCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:110; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.SignContractCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:116; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:132; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:137; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:146; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.AssessRiskCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:147; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:150; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.StartFlowCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:163; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.StartFlowCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:51; → unresolved: No subscriber of the same contract or of a contract with the same name was found.
- publishes `dotnet:src/Leasing.AppServices/Leasing.AppServices.csproj:T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (transport unknown, candidate), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:96; → unresolved: No subscriber of the same contract or of a contract with the same name was found.

## In-process dispatch (1)

- sends `T:MediatR.IRequest`1` (mediatr), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:37; → candidate `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10; candidate `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26; candidate `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:12; and 8 more links

## Dependency injection (7 registrations, 4 consumed services)

Lifetimes: 7 singleton.

- `T:Leasing.AppServices.Flows.IFlowStore` → `T:Leasing.AppServices.Tests.InMemoryFlowStore` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:26
- `T:Leasing.AppServices.Flows.IFlowChangeNotifier` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:27
- `T:Leasing.AppServices.Ports.ICreditCheckGateway` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:28
- `T:Leasing.AppServices.Ports.INoticeOutbox` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:29
- `T:Leasing.AppServices.Ports.ILeaseContractPublisher` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:30
- `T:Leasing.AppServices.Ports.ILeaseDocuments` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:31
- `T:Leasing.Pricing.IQuotePricing` → `T:Leasing.AppServices.Tests.Recorder` (singleton), tests/Leasing.AppServices.Tests/FlowEngineTests.cs:32

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Leasing.AppServices.Tests --kind entity`

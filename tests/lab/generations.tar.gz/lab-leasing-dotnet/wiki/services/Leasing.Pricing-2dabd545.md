# Leasing.Pricing

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Leasing.Pricing/Leasing.Pricing.csproj`
- Kind: library
- Context card: [context/projects/Leasing.Pricing-2dabd545.md](../../context/projects/Leasing.Pricing-2dabd545.md)

## Neighbours

```mermaid
flowchart LR
  n2dabd5456b[["Leasing.Pricing"]]
  n3430966f3e["Leasing.Pricing.Tests"]
  n3430966f3e -->|"di ×1"| n2dabd5456b
```

## Endpoints (0)

None found.

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## Dependency injection (1 registrations, 2 consumed services)

Lifetimes: 1 scoped.

- `T:Leasing.Pricing.IQuotePricing` → `T:Leasing.Pricing.QuotePricingService` (scoped), src/Leasing.Pricing/PricingModuleExtensions.cs:20

## Configuration keys (0, values never stored)

None found.

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Leasing.Pricing --kind entity`

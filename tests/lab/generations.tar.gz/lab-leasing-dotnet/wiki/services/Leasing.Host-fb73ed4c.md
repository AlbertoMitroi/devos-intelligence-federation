# Leasing.Host

- Commit: `c2dbb16a3b95d836f544868fdaa3dfa9b327ca1b`
- Engine: dotnet-intelligence 0.1.0
- Status: complete
- Project: `src/Leasing.Host/Leasing.Host.csproj`
- Kind: service
- Context card: [context/projects/Leasing.Host-fb73ed4c.md](../../context/projects/Leasing.Host-fb73ed4c.md)

## Neighbours

```mermaid
flowchart LR
  n4df53c14e5["Leasing.AppServices"]
  nfb73ed4c0c[["Leasing.Host"]]
  nfb73ed4c0c -->|"inprocess ×16"| n4df53c14e5
```

## Endpoints (17)

- GET `/v1/admin/portfolio` → `M:Leasing.Host.Controllers.V1.AdminController.Portfolio(System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AdminController.cs:14
- GET `/v1/applications` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Search(System.String,System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:20
- GET `/v1/applications/{}` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:24
- POST `/v1/applications/{}/review` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Review(System.Guid,Leasing.Host.Controllers.V1.ReviewApplicationRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:28
- POST `/v1/applications/{}/actions/withdraw` → `M:Leasing.Host.Controllers.V1.ApplicationsController.Withdraw(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/ApplicationsController.cs:33
- GET `/v1/assessments` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Search(System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:20
- GET `/v1/assessments/{}` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:24
- POST `/v1/assessments/{}/assess` → `M:Leasing.Host.Controllers.V1.AssessmentsController.Assess(System.Guid,Leasing.Host.Controllers.V1.AssessRiskRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/AssessmentsController.cs:28
- GET `/v1/leases` → `M:Leasing.Host.Controllers.V1.LeasesController.Search(System.String,System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:21
- GET `/v1/leases/{}` → `M:Leasing.Host.Controllers.V1.LeasesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:25
- GET `/v1/leases/{}/document` → `M:Leasing.Host.Controllers.V1.LeasesController.GetDocument(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:29
- POST `/v1/leases/{}/sign` → `M:Leasing.Host.Controllers.V1.LeasesController.Sign(System.Guid,Leasing.Host.Controllers.V1.SignContractRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/LeasesController.cs:33
- GET `/v1/quotes` → `M:Leasing.Host.Controllers.V1.QuotesController.Search(System.String,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:23
- GET `/v1/quotes/{}` → `M:Leasing.Host.Controllers.V1.QuotesController.Get(System.Guid,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:27
- POST `/v1/quotes/{}/accept` → `M:Leasing.Host.Controllers.V1.QuotesController.Accept(System.Guid,Leasing.Host.Controllers.V1.AcceptQuoteRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:31
- POST `/v1/quotes/{}/recalculate` → `M:Leasing.Host.Controllers.V1.QuotesController.Recalculate(System.Guid,Leasing.Host.Controllers.V1.RecalculateQuoteRequest,System.Threading.CancellationToken)`, src/Leasing.Host/Controllers/V1/QuotesController.cs:36
- hub `T:Leasing.Host.Hubs.LeasingHub` at `/hubs/leasing`, src/Leasing.Host/Program.cs:42

## Outgoing calls (0)

None found.

## Messages (0 published, 0 subscribed)

None found.

## In-process dispatch (16)

- sends `T:Leasing.AppServices.Flows.Queries.GetPortfolioSummaryQuery` (mediatr), src/Leasing.Host/Controllers/V1/AdminController.cs:16; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:22; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:26; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.ReviewApplicationCommand` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (mediatr), src/Leasing.Host/Controllers/V1/ApplicationsController.cs:36; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:22; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:26; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.AssessRiskCommand` (mediatr), src/Leasing.Host/Controllers/V1/AssessmentsController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:23; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:27; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Queries.GetLeaseDocumentQuery` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:31; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/PortfolioQueries.cs:12
- sends `T:Leasing.AppServices.Flows.Commands.SignContractCommand` (mediatr), src/Leasing.Host/Controllers/V1/LeasesController.cs:36; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Queries.SearchFlowsQuery` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:25; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:26
- sends `T:Leasing.AppServices.Flows.Queries.GetFlowQuery` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:29; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Queries/FlowQueries.cs:10
- sends `T:Leasing.AppServices.Flows.Commands.AcceptQuoteCommand` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:34; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/UserTaskCommands.cs:14
- sends `T:Leasing.AppServices.Flows.Commands.ExecuteFlowActionCommand` (mediatr), src/Leasing.Host/Controllers/V1/QuotesController.cs:39; → exact `Leasing.AppServices` src/Leasing.AppServices/Flows/Commands/FlowCommands.cs:24

## Dependency injection (0 registrations, 6 consumed services)

None found.

## Configuration keys (36, values never stored)

- `AllowedHosts`, src/Leasing.Host/appsettings.json:8
- `Authentication:LocalDev:Audience`, src/Leasing.Host/appsettings.Docker.json:16 and 1 more
- `Authentication:LocalDev:Issuer`, src/Leasing.Host/appsettings.Docker.json:15 and 1 more
- `Authentication:LocalDev:SigningKey`, src/Leasing.Host/appsettings.Docker.json:17 and 1 more
- `AzureAd:Audience`, src/Leasing.Host/appsettings.json:13
- `AzureAd:ClientId`, src/Leasing.Host/appsettings.json:12
- `AzureAd:Instance`, src/Leasing.Host/appsettings.json:10
- `AzureAd:TenantId`, src/Leasing.Host/appsettings.json:11
- `Clients:Pricing:BaseAddress`, src/Leasing.Host/appsettings.Dev.json:4 and 2 more
- `Clients:RateCards:BaseAddress`, src/Leasing.Host/appsettings.Dev.json:7 and 2 more
- `ConnectionStrings:LeasingDb` (secret), src/Leasing.Host/appsettings.Docker.json:3 and 2 more
- `Cors:Origins:0`, src/Leasing.Host/appsettings.Dev.json:30 and 2 more
- `Cors:Origins:1`, src/Leasing.Host/appsettings.Docker.json:34
- `Elasticsearch:Indexes:Flows`, src/Leasing.Host/appsettings.json:56
- `Elasticsearch:Url`, src/Leasing.Host/appsettings.Dev.json:27 and 2 more
- `Kafka:BootstrapServers`, src/Leasing.Host/appsettings.Dev.json:23 and 2 more
- `Kafka:ConsumerGroup`, src/Leasing.Host/appsettings.json:46
- `Kafka:Enabled`, src/Leasing.Host/appsettings.json:43
- `Kafka:SchemaRegistryUrl`, src/Leasing.Host/appsettings.Dev.json:24 and 2 more
- `Kafka:Topics:Applications`, src/Leasing.Host/appsettings.json:48
- `Kafka:Topics:Contracts`, src/Leasing.Host/appsettings.json:50
- `Kafka:Topics:Enrichment`, src/Leasing.Host/appsettings.json:49
- `Logging:LogLevel:Default`, src/Leasing.Host/appsettings.json:4
- `Logging:LogLevel:Microsoft.AspNetCore`, src/Leasing.Host/appsettings.json:5
- `Messaging:AzureServiceBusHost:ConnectionString` (secret), src/Leasing.Host/appsettings.Dev.json:13
- `Messaging:CreditBureauSimulator`, src/Leasing.Host/appsettings.Docker.json:24 and 2 more
- `Messaging:Queues:CreditCheckRequests`, src/Leasing.Host/appsettings.Dev.json:16 and 1 more
- `Messaging:Queues:CreditCheckResponses`, src/Leasing.Host/appsettings.Dev.json:17 and 1 more
- `Messaging:Queues:NoticeOutbox`, src/Leasing.Host/appsettings.Dev.json:18 and 1 more
- `Messaging:Queues:Projections`, src/Leasing.Host/appsettings.Dev.json:19 and 1 more
- `Messaging:RabbitMqHost:Host`, src/Leasing.Host/appsettings.Docker.json:22 and 1 more
- `Messaging:RabbitMqHost:Password` (secret), src/Leasing.Host/appsettings.json:32
- `Messaging:RabbitMqHost:Username`, src/Leasing.Host/appsettings.json:31
- `Messaging:RabbitMqHost:VirtualHost`, src/Leasing.Host/appsettings.json:30
- `Messaging:Transport`, src/Leasing.Host/appsettings.Dev.json:11 and 1 more
- `WorkTeams:UnderwritingTeam:Members:0`, src/Leasing.Host/appsettings.Local.json:16

## Legend

| Resolution | Meaning | Diagram |
|---|---|---|
| exact | both sides resolved by symbols and normalized fields | solid arrow `-->` |
| ambiguous | several targets match; all are kept | dotted arrow `-.->` labelled ambiguous |
| candidate | a match that relies on a heuristic or a configured convention | dotted arrow `-.->` labelled candidate |
| unresolved | no target found; the reason is in the link | not drawn, listed under gaps |

## Queries

This page is generated from `graph/*.ndjson`; the same facts come from:

- `dotnet-intelligence query <generation> routes`
- `dotnet-intelligence query <generation> http`
- `dotnet-intelligence query <generation> messages`
- `dotnet-intelligence query <generation> search Leasing.Host --kind entity`

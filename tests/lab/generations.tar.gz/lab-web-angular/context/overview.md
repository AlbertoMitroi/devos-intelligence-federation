# Overview: https://github.com/AlbertoMitroi/devos-lab-web.git

Commit `66264d5967946d301f00e979cee2231b13982bdc`, generation status **complete**. Produced by angular-intelligence; every line cites `path:line` evidence.

## Projects

| Project | Kind | Type | Load mode | Compiler | Compilation errors |
|---|---|---|---|---|---|
| `.` (lab-web) | angular | application | semantic | typescript 6.0.3 (repository) | 0 |

## Routes

- `/`: redirect to `applications` (`src/app/app.routes.ts:4`)
- `/admin/portfolio`: loadComponent `Portfolio` (`src/app/app.routes.ts:9`)
- `/applications`: loadChildren `applicationRoutes` (`src/app/app.routes.ts:5`)
- `/applications`: loadComponent `ApplicationList` (`src/app/features/applications/applications.routes.ts:4`)
- `/applications/:flowId`: loadComponent `ApplicationDetail` (`src/app/features/applications/applications.routes.ts:5`)
- `/assessments`: loadComponent `AssessmentList` (`src/app/app.routes.ts:6`)
- `/leases`: loadComponent `LeaseList` (`src/app/features/leases/leases.routes.ts:4`)
- `/leases`: loadChildren `leaseRoutes` (`src/app/app.routes.ts:8`)
- `/leases/:flowId`: loadComponent `LeaseDetail` (`src/app/features/leases/leases.routes.ts:5`)
- `/quotes`: loadChildren `quoteRoutes` (`src/app/app.routes.ts:7`)
- `/quotes`: loadComponent `QuoteList` (`src/app/features/quotes/quotes.routes.ts:4`)
- `/quotes/:flowId`: loadComponent `QuoteDetail` (`src/app/features/quotes/quotes.routes.ts:5`)

## Feature areas

First route segment and the number of routes below it.

- `(root)`: 1
- `admin`: 1
- `applications`: 3
- `assessments`: 1
- `leases`: 3
- `quotes`: 3

## HTTP calls

| Method | Route | Base address | Client | Resolution | Evidence |
|---|---|---|---|---|---|
| GET | `/v1/admin/portfolio` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `PortfolioService` | exact | `src/app/features/admin/portfolio.service.ts:17` |
| GET | `/v1/applications` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `ApplicationsService` | exact | `src/app/features/applications/applications.service.ts:20` |
| GET | `/v1/applications/{}` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `ApplicationsService` | exact | `src/app/features/applications/applications.service.ts:24` |
| POST | `/v1/applications/{}/actions/withdraw` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `ApplicationsService` | exact | `src/app/features/applications/applications.service.ts:32` |
| POST | `/v1/applications/{}/review` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `ApplicationsService` | exact | `src/app/features/applications/applications.service.ts:28` |
| GET | `/v1/assessments` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `AssessmentsService` | exact | `src/app/features/assessments/assessments.service.ts:13` |
| POST | `/v1/assessments/{}/assess` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `AssessmentsService` | exact | `src/app/features/assessments/assessments.service.ts:17` |
| GET | `/v1/leases` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `LeasesService` | exact | `src/app/features/leases/leases.service.ts:27` |
| GET | `/v1/leases/{}` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `LeasesService` | exact | `src/app/features/leases/leases.service.ts:31` |
| GET | `/v1/leases/{}/document` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `LeasesService` | exact | `src/app/features/leases/leases.service.ts:35` |
| POST | `/v1/leases/{}/sign` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `LeasesService` | exact | `src/app/features/leases/leases.service.ts:39` |
| GET | `/v1/quotes` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `QuotesService` | exact | `src/app/features/quotes/quotes.service.ts:13` |
| GET | `/v1/quotes/{}` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `QuotesService` | exact | `src/app/features/quotes/quotes.service.ts:17` |
| POST | `/v1/quotes/{}/accept` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `QuotesService` | exact | `src/app/features/quotes/quotes.service.ts:21` |
| POST | `/v1/quotes/{}/recalculate` | environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080) | `QuotesService` | exact | `src/app/features/quotes/quotes.service.ts:25` |

## Real time

- realtime.subscribe `/hubs/leasing` method `taskAssigned` (`src/app/core/realtime/leasing-hub.service.ts:20`, `src/app/core/realtime/leasing-hub.service.ts:42`)
- realtime.subscribe `/hubs/leasing` method `flowUpdated` (`src/app/core/realtime/leasing-hub.service.ts:20`, `src/app/core/realtime/leasing-hub.service.ts:41`)
- realtime.connection `/hubs/leasing` (`src/app/core/realtime/leasing-hub.service.ts:20`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

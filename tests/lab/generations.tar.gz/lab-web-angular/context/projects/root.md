# Project lab-web (`.`)

Kind angular, type application, load mode **semantic** (typescript 6.0.3 (repository) program with type checker). tsconfig `tsconfig.app.json`.

## Components

- `App` selector `app-root`, template `src/app/app.html` (`src/app/app.ts:5`)
- `Portfolio` selector `app-portfolio`, template `src/app/features/admin/portfolio.ts` (`src/app/features/admin/portfolio.ts:5`)
- `ApplicationDetail` selector `app-application-detail`, template `src/app/features/applications/application-detail.ts` (`src/app/features/applications/application-detail.ts:6`)
- `ApplicationList` selector `app-application-list`, template `src/app/features/applications/application-list.ts` (`src/app/features/applications/application-list.ts:8`)
- `AssessmentList` selector `app-assessment-list`, template `src/app/features/assessments/assessment-list.ts` (`src/app/features/assessments/assessment-list.ts:5`)
- `LeaseDetail` selector `app-lease-detail`, template `src/app/features/leases/lease-detail.ts` (`src/app/features/leases/lease-detail.ts:6`)
- `LeaseList` selector `app-lease-list`, template `src/app/features/leases/lease-list.ts` (`src/app/features/leases/lease-list.ts:7`)
- `QuoteDetail` selector `app-quote-detail`, template `src/app/features/quotes/quote-detail.ts` (`src/app/features/quotes/quote-detail.ts:6`)
- `QuoteList` selector `app-quote-list`, template `src/app/features/quotes/quote-list.ts` (`src/app/features/quotes/quote-list.ts:7`)

## Providers

- `AuthTokenService` as `AuthTokenService`, scope root (`src/app/core/auth/auth-token.service.ts:7`)
- `AssessmentsService` as `AssessmentsService`, scope root (`src/app/features/assessments/assessments.service.ts:7`)
- `LeasingHubService` as `LeasingHubService`, scope root (`src/app/core/realtime/leasing-hub.service.ts:28`)
- `QuotesService` as `QuotesService`, scope root (`src/app/features/quotes/quotes.service.ts:7`)
- `PortfolioService` as `PortfolioService`, scope root (`src/app/features/admin/portfolio.service.ts:12`)
- `LeasesService` as `LeasesService`, scope root (`src/app/features/leases/leases.service.ts:20`)
- `ApplicationsService` as `ApplicationsService`, scope root (`src/app/features/applications/applications.service.ts:7`)

## Routes

- `/` (`src/app/app.routes.ts:4`)
- `/admin/portfolio` (`src/app/app.routes.ts:9`)
- `/applications` (`src/app/app.routes.ts:5`)
- `/applications` (`src/app/features/applications/applications.routes.ts:4`)
- `/applications/:flowId` (`src/app/features/applications/applications.routes.ts:5`)
- `/assessments` (`src/app/app.routes.ts:6`)
- `/leases` (`src/app/app.routes.ts:8`)
- `/leases` (`src/app/features/leases/leases.routes.ts:4`)
- `/leases/:flowId` (`src/app/features/leases/leases.routes.ts:5`)
- `/quotes` (`src/app/app.routes.ts:7`)
- `/quotes` (`src/app/features/quotes/quotes.routes.ts:4`)
- `/quotes/:flowId` (`src/app/features/quotes/quotes.routes.ts:5`)

## HTTP calls

- GET `/v1/admin/portfolio` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `PortfolioService`, exact (`src/app/features/admin/portfolio.service.ts:17`)
- GET `/v1/applications` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `ApplicationsService`, exact (`src/app/features/applications/applications.service.ts:20`)
- GET `/v1/applications/{}` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `ApplicationsService`, exact (`src/app/features/applications/applications.service.ts:24`)
- POST `/v1/applications/{}/actions/withdraw` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `ApplicationsService`, exact (`src/app/features/applications/applications.service.ts:32`)
- POST `/v1/applications/{}/review` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `ApplicationsService`, exact (`src/app/features/applications/applications.service.ts:28`)
- GET `/v1/assessments` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `AssessmentsService`, exact (`src/app/features/assessments/assessments.service.ts:13`)
- POST `/v1/assessments/{}/assess` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `AssessmentsService`, exact (`src/app/features/assessments/assessments.service.ts:17`)
- GET `/v1/leases` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `LeasesService`, exact (`src/app/features/leases/leases.service.ts:27`)
- GET `/v1/leases/{}` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `LeasesService`, exact (`src/app/features/leases/leases.service.ts:31`)
- GET `/v1/leases/{}/document` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `LeasesService`, exact (`src/app/features/leases/leases.service.ts:35`)
- POST `/v1/leases/{}/sign` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `LeasesService`, exact (`src/app/features/leases/leases.service.ts:39`)
- GET `/v1/quotes` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `QuotesService`, exact (`src/app/features/quotes/quotes.service.ts:13`)
- GET `/v1/quotes/{}` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `QuotesService`, exact (`src/app/features/quotes/quotes.service.ts:17`)
- POST `/v1/quotes/{}/accept` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `QuotesService`, exact (`src/app/features/quotes/quotes.service.ts:21`)
- POST `/v1/quotes/{}/recalculate` base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), client `QuotesService`, exact (`src/app/features/quotes/quotes.service.ts:25`)

## Packages (direct)

- `@angular/build@22.2.5`
- `@angular/cli@22.2.5`
- `@angular/common@22.2.3`
- `@angular/compiler@22.2.3`
- `@angular/compiler-cli@22.2.3`
- `@angular/core@22.2.3`
- `@angular/forms@22.2.3`
- `@angular/platform-browser@22.2.3`
- `@angular/router@22.2.3`
- `@microsoft/signalr@10.0.11`
- `jsdom@30.1.3`
- `prettier@3.9.10`
- `rxjs@7.8.2`
- `tslib@2.8.1`
- `typescript@6.0.3`
- `vitest@5.0.5`

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

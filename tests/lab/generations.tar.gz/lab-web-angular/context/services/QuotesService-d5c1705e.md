# Service QuotesService

Entity `ts:.:src/app/features/quotes/quotes.service#QuotesService`, project `.`.

## HTTP calls

- GET `/v1/quotes` (template `/v1/quotes`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `list`, exact (`src/app/features/quotes/quotes.service.ts:13`)
- GET `/v1/quotes/{}` (template `/v1/quotes/{}`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `get`, exact (`src/app/features/quotes/quotes.service.ts:17`)
- POST `/v1/quotes/{}/accept` (template `/v1/quotes/{}/accept`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `accept`, exact (`src/app/features/quotes/quotes.service.ts:21`)
- POST `/v1/quotes/{}/recalculate` (template `/v1/quotes/{}/recalculate`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `recalculate`, exact (`src/app/features/quotes/quotes.service.ts:25`)

## Injected into

- `QuoteList` via inject (`src/app/features/quotes/quote-list.ts:20`)
- `QuoteDetail` via inject (`src/app/features/quotes/quote-detail.ts:25`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

# Service LeasesService

Entity `ts:.:src/app/features/leases/leases.service#LeasesService`, project `.`.

## HTTP calls

- GET `/v1/leases` (template `/v1/leases`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `search`, exact (`src/app/features/leases/leases.service.ts:27`)
- GET `/v1/leases/{}` (template `/v1/leases/{}`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `get`, exact (`src/app/features/leases/leases.service.ts:31`)
- GET `/v1/leases/{}/document` (template `/v1/leases/{}/document`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `document`, exact (`src/app/features/leases/leases.service.ts:35`)
- POST `/v1/leases/{}/sign` (template `/v1/leases/{}/sign`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `sign`, exact (`src/app/features/leases/leases.service.ts:39`)

## Injected into

- `LeaseDetail` via inject (`src/app/features/leases/lease-detail.ts:24`)
- `LeaseList` via inject (`src/app/features/leases/lease-list.ts:24`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

# Service AssessmentsService

Entity `ts:.:src/app/features/assessments/assessments.service#AssessmentsService`, project `.`.

## HTTP calls

- GET `/v1/assessments` (template `/v1/assessments`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `list`, exact (`src/app/features/assessments/assessments.service.ts:13`)
- POST `/v1/assessments/{}/assess` (template `/v1/assessments/{}/assess`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `assess`, exact (`src/app/features/assessments/assessments.service.ts:17`)

## Injected into

- `AssessmentList` via inject (`src/app/features/assessments/assessment-list.ts:24`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

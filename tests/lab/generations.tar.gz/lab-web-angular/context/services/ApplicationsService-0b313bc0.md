# Service ApplicationsService

Entity `ts:.:src/app/features/applications/applications.service#ApplicationsService`, project `.`.

## HTTP calls

- GET `/v1/applications` (template `/v1/applications`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `search`, exact (`src/app/features/applications/applications.service.ts:20`)
- GET `/v1/applications/{}` (template `/v1/applications/{}`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `get`, exact (`src/app/features/applications/applications.service.ts:24`)
- POST `/v1/applications/{}/actions/withdraw` (template `/v1/applications/{}/actions/withdraw`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `withdraw`, exact (`src/app/features/applications/applications.service.ts:32`)
- POST `/v1/applications/{}/review` (template `/v1/applications/{}/review`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `review`, exact (`src/app/features/applications/applications.service.ts:28`)

## Injected into

- `ApplicationList` via inject (`src/app/features/applications/application-list.ts:35`)
- `ApplicationDetail` via inject (`src/app/features/applications/application-detail.ts:26`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.

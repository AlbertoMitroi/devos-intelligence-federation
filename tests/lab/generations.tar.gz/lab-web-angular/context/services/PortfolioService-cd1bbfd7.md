# Service PortfolioService

Entity `ts:.:src/app/features/admin/portfolio.service#PortfolioService`, project `.`.

## HTTP calls

- GET `/v1/admin/portfolio` (template `/v1/admin/portfolio`), base environment `environment.apiUrl` (default@.=https://app-lab-leasing-dev.azurewebsites.net, development@.=http://localhost:5080), from `summary`, exact (`src/app/features/admin/portfolio.service.ts:17`)

## Injected into

- `Portfolio` via inject (`src/app/features/admin/portfolio.ts:24`)

## What could not be determined

- Nothing reported for this scope. Runtime behaviour (values chosen at run time, server responses) is out of scope by design.
